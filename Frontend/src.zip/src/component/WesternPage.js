// src/components/Western.js
import React from 'react';
import DressCategoryPage from './DressCategoryPage';

const dresses = [
  {
    title: "Denim Jacket",
    description: "Trendy and perfect for casual Western vibes.",
    imageUrl: "/images/western1.jpg"
  },
  {
    title: "Crop Top & Jeans",
    description: "Stylish and comfortable everyday Western wear.",
    imageUrl: "/images/western2.jpg"
  }
];

const Western = () => <DressCategoryPage title="Western Styles" dresses={dresses} />;
export default Western;
