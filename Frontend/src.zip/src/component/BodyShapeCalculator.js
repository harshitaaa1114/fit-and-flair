
// // // import React, { useState, useRef, useEffect } from "react";
// // // import Navbar from "./Navbar";

// // // const requiredFields = [
// // //   { key: "gender", question: "Please enter your gender (male/female):" },
// // //   { key: "shoulder", question: "Enter your shoulder measurement with unit (e.g., 40 cm):" },
// // //   { key: "chest", question: "Enter your chest measurement with unit (e.g., 90 cm):" },
// // //   { key: "waist", question: "Enter your waist measurement with unit (e.g., 70 cm):" },
// // //   { key: "hip", question: "Enter your hip measurement with unit (e.g., 95 cm):" },
// // //   { key: "height", question: "Enter your height with unit (e.g., 170 cm):" },
// // // ];

// // // function parseValueUnit(input) {
// // //   const parts = input.trim().split(" ");
// // //   if (parts.length !== 2) return null;
// // //   const value = parseFloat(parts[0]);
// // //   const unit = parts[1].toLowerCase();
// // //   if (isNaN(value)) return null;
// // //   if (!["cm", "inches", "feet"].includes(unit)) return null;
// // //   return { value, unit };
// // // }

// // // export default function BodyShapeApp() {
// // //   const messagesEndRef = useRef(null);

// // //   // chat messages & flow states
// // //   const [chatMessages, setChatMessages] = useState([
// // //     { id: 1, text: "Welcome! Let's calculate your body shape. " + requiredFields[0].question, fromUser: false },
// // //   ]);
// // //   const [currentFieldIndex, setCurrentFieldIndex] = useState(0);
// // //   const [formData, setFormData] = useState({});
// // //   const [input, setInput] = useState("");

// // //   // pages: "chat", "result", "recommendations"
// // //   const [currentPage, setCurrentPage] = useState("chat");
// // //   const [chosenStyle, setChosenStyle] = useState("");

// // //   useEffect(() => {
// // //     messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
// // //   }, [chatMessages]);

// // //   const addBotMessage = (text) => {
// // //     setChatMessages((msgs) => [...msgs, { id: Date.now(), text, fromUser: false }]);
// // //   };

// // //   const addUserMessage = (text) => {
// // //     setChatMessages((msgs) => [...msgs, { id: Date.now(), text, fromUser: true }]);
// // //   };

// // //   const handleSend = () => {
// // //     const userInput = input.trim();
// // //     if (!userInput) return;
// // //     addUserMessage(userInput);
// // //     setInput("");

// // //     if (currentPage === "chat") {
// // //       const currentField = requiredFields[currentFieldIndex];

// // //       if (currentField?.key === "gender") {
// // //         const val = userInput.toLowerCase();
// // //         if (val === "male" || val === "female") {
// // //           setFormData({ ...formData, gender: val });
// // //           const nextIndex = currentFieldIndex + 1;
// // //           if (nextIndex < requiredFields.length) {
// // //             addBotMessage(requiredFields[nextIndex].question);
// // //             setCurrentFieldIndex(nextIndex);
// // //           }
// // //         } else {
// // //           addBotMessage("Invalid gender. Please type 'male' or 'female'.");
// // //         }
// // //       } else if (currentField) {
// // //         const parsed = parseValueUnit(userInput);
// // //         if (parsed) {
// // //           const newFormData = { ...formData, [currentField.key]: parsed };
// // //           setFormData(newFormData);
// // //           const nextIndex = currentFieldIndex + 1;
// // //           if (nextIndex < requiredFields.length) {
// // //             addBotMessage(requiredFields[nextIndex].question);
// // //             setCurrentFieldIndex(nextIndex);
// // //           } else {
// // //             // All inputs done - show result page
// // //             setCurrentPage("result");
// // //           }
// // //         } else {
// // //           addBotMessage("Invalid format. Please enter a number followed by a unit (cm, inches, feet). Example: 40 cm");
// // //         }
// // //       }
// // //     }
// // //   };

// // //   function calculateBodyShape(data) {
     
// // //     // dummy calc, replace with your real logic
// // //     return JSON.stringify(data, null, 2);
// // //   }

// // //   // ====== RENDER PAGES ======

// // //   // Chat page
// // //   const renderChatPage = () => (
// // //     <div>
// // //       <Navbar/>
// // //     <div
// // //       style={{
// // //         background: "linear-gradient(135deg, #ffe7d1 0%, #e6c1a8 100%)",
// // //         minHeight: "100vh",
// // //         paddingTop: "40px",
// // //         display: "flex",
// // //         justifyContent: "center",
// // //       }}
// // //     >
      
// // //       <div style={styles.chatContainer}>
// // //         <div style={styles.chatMessages}>
// // //           {chatMessages.map((msg) => (
// // //             <div
// // //               key={msg.id}
// // //               style={{
// // //                 ...styles.chatMessage,
// // //                 alignSelf: msg.fromUser ? "flex-end" : "flex-start",
// // //                 backgroundColor: msg.fromUser ? "#9c5c34" : "#ffcba4",
// // //                 color: msg.fromUser ? "#fff" : "#5D432C",
// // //                 whiteSpace: "pre-line",
// // //               }}
// // //             >
// // //               {msg.text}
// // //             </div>
// // //           ))}
// // //           <div ref={messagesEndRef} />
// // //         </div>
// // //         <div style={styles.chatInputRow}>
// // //           <input
// // //             type="text"
// // //             placeholder="Type your answer..."
// // //             value={input}
// // //             onChange={(e) => setInput(e.target.value)}
// // //             onKeyPress={(e) => {
// // //               if (e.key === "Enter") {
// // //                 e.preventDefault();
// // //                 handleSend();
// // //               }
// // //             }}
// // //             style={styles.chatInput}
// // //           />
// // //           <button onClick={handleSend} style={styles.chatSendButton}>
// // //             Send
// // //           </button>
// // //         </div>
// // //       </div>
// // //     </div>
// // //     </div>
// // //   );

// // //   // Result page with "View Recommendations" buttons
// // //   const renderResultPage = () => {
    
// // //     const resultText = calculateBodyShape(formData);
// // //     const styleOptions = ["formal", "western", "traditional", "casual", "indowestern"];

// // //     return (
// // //       <div>
// // //       <Navbar/>
// // //       <div style={{ padding: 20, maxWidth: 600, margin: "40px auto", backgroundColor: "#fff", borderRadius: 12, boxShadow: "0 0 10px rgba(0,0,0,0.1)" }}>
// // //         <h2>Your Body Shape Summary</h2>
// // //         <pre
// // //           style={{
// // //             backgroundColor: "#f0f0f0",
// // //             padding: 15,
// // //             borderRadius: 8,
// // //             fontSize: 14,
// // //             whiteSpace: "pre-wrap",
// // //           }}
// // //         >
// // //           {resultText}
// // //         </pre>

// // //         <h3 style={{ marginTop: 20 }}>View Style Recommendations</h3>
// // //         <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
// // //           {styleOptions.map((style) => (
// // //             <button
// // //               key={style}
// // //               onClick={() => {
// // //                 setChosenStyle(style);
// // //                 setCurrentPage("recommendations");
// // //               }}
// // //               style={{
// // //                 padding: "10px 16px",
// // //                 backgroundColor: "#9c5c34",
// // //                 color: "white",
// // //                 border: "none",
// // //                 borderRadius: 8,
// // //                 cursor: "pointer",
// // //                 textTransform: "capitalize",
// // //               }}
// // //             >
// // //               {style}
// // //             </button>
// // //           ))}
// // //         </div>

// // //         <button
// // //           onClick={() => {
// // //             setCurrentPage("chat");
// // //             setChatMessages([
// // //               { id: 1, text: "Welcome! Let's calculate your body shape. " + requiredFields[0].question, fromUser: false },
// // //             ]);
// // //             setCurrentFieldIndex(0);
// // //             setFormData({});
// // //             setInput("");
// // //             setChosenStyle("");
// // //           }}
// // //           style={{
// // //             marginTop: 30,
// // //             padding: "10px 20px",
// // //             backgroundColor: "#d9534f",
// // //             color: "white",
// // //             border: "none",
// // //             borderRadius: 8,
// // //             cursor: "pointer",
// // //           }}
// // //         >
// // //           Restart Calculator
// // //         </button>
// // //       </div>
// // //       </div>
    
// // //     );
// // //   };

// // //   // Recommendation page for chosen style
// // //   const renderRecommendationPage = () => (
// // //     <div>
// // //       <Navbar/>
    
// // //     <div style={{ padding: 20, maxWidth: 600, margin: "40px auto", backgroundColor: "#fff", borderRadius: 12, boxShadow: "0 0 10px rgba(0,0,0,0.1)" }}>
// // //       <h2>{chosenStyle.charAt(0).toUpperCase() + chosenStyle.slice(1)} Style Recommendations</h2>
// // //       <p>Here are some great {chosenStyle} style recommendations for your body shape!</p>

// // //       {/* TODO: Replace below with actual recommendations */}
// // //       <ul>
// // //         <li>Recommendation 1 for {chosenStyle}</li>
// // //         <li>Recommendation 2 for {chosenStyle}</li>
// // //         <li>Recommendation 3 for {chosenStyle}</li>
// // //       </ul>

// // //       <button
// // //         onClick={() => setCurrentPage("result")}
// // //         style={{
// // //           marginTop: 20,
// // //           padding: "10px 20px",
// // //           cursor: "pointer",
// // //           backgroundColor: "#9c5c34",
// // //           color: "white",
// // //           border: "none",
// // //           borderRadius: 8,
// // //         }}
// // //       >
// // //         Back to Results
// // //       </button>
// // //       <button
// // //         onClick={() => {
// // //           setCurrentPage("chat");
// // //           setChatMessages([
// // //             { id: 1, text: "Welcome! Let's calculate your body shape. " + requiredFields[0].question, fromUser: false },
// // //           ]);
// // //           setCurrentFieldIndex(0);
// // //           setFormData({});
// // //           setInput("");
// // //           setChosenStyle("");
// // //         }}
// // //         style={{
// // //           marginTop: 10,
// // //           padding: "10px 20px",
// // //           cursor: "pointer",
// // //           backgroundColor: "#d9534f",
// // //           color: "white",
// // //           border: "none",
// // //           borderRadius: 8,
// // //         }}
// // //       >
// // //         Restart Calculator
// // //       </button>
// // //     </div>
    
// // //   );

// // //   // Main render
// // //   if (currentPage === "chat") return renderChatPage();
// // //   if (currentPage === "result") return renderResultPage();
// // //   if (currentPage === "recommendations") return renderRecommendationPage();

// // //   return null;
// // // }

// // // const styles = {
// // //   chatContainer: {
// // //     margin: "40px auto",
// // //     maxWidth: "600px",
// // //     height: "400px",
// // //     border: "1px solid #ccc",
// // //     borderRadius: "12px",
// // //     display: "flex",
// // //     flexDirection: "column",
// // //     backgroundColor: "#fff",
// // //     boxShadow: "0 0 10px rgba(0,0,0,0.1)",
// // //   },
// // //   chatMessages: {
// // //     flex: 1,
// // //     padding: "15px",
// // //     overflowY: "auto",
// // //     fontSize: "15px",
// // //   },
// // //   chatMessage: {
// // //     padding: "10px 15px",
// // //     margin: "8px 0",
// // //     borderRadius: "18px",
// // //     maxWidth: "75%",
// // //   },
// // //   chatInputRow: {
// // //     display: "flex",
// // //     borderTop: "1px solid #ddd",
// // //     padding: "10px",
// // //   },
// // //   chatInput: {
// // //     flex: 1,
// // //     borderRadius: "20px",
// // //     border: "1px solid #ccc",
// // //     padding: "10px 15px",
// // //     fontSize: "16px",
// // //   },
// // //   chatSendButton: {
// // //     marginLeft: 10,
// // //     padding: "10px 20px",
// // //     backgroundColor: "#9c5c34",
// // //     color: "white",
// // //     border: "none",
// // //     borderRadius: "20px",
// // //     cursor: "pointer",
// // //   },
// // // };
// import React, { useState, useRef, useEffect } from "react";


// const requiredFields = [
//   { key: "gender", question: "Please enter your gender (male/female):" },
//   { key: "shoulder", question: "Enter your shoulder measurement with unit (e.g., 40 cm):" },
//   { key: "chest", question: "Enter your chest measurement with unit (e.g., 90 cm):" },
//   { key: "waist", question: "Enter your waist measurement with unit (e.g., 70 cm):" },
//   { key: "hip", question: "Enter your hip measurement with unit (e.g., 95 cm):" },
//   { key: "height", question: "Enter your height with unit (e.g., 170 cm):" },
// ];

// function parseValueUnit(input) {
//   const parts = input.trim().split(" ");
//   if (parts.length !== 2) return null;
//   const value = parseFloat(parts[0]);
//   const unit = parts[1].toLowerCase();
//   if (isNaN(value)) return null;
//   if (!["cm", "inches", "feet"].includes(unit)) return null;
//   return { value, unit };
// }

// function convertToCm({ value, unit }) {
//   if (unit === "cm") return value;
//   if (unit === "inches") return value * 2.54;
//   if (unit === "feet") return value * 30.48;
//   return value;
// }

// function calculateBodyShape(data) {
//   const gender = data.gender;
//   const shoulder = convertToCm(data.shoulder);
//   const chest = convertToCm(data.chest);
//   const waist = convertToCm(data.waist);
//   const hip = convertToCm(data.hip);
//   const height = convertToCm(data.height);

//   const heightCategory = height < 150 ? "Short" : height < 170 ? "Average" : "Tall";

//   let shape = "Unknown";

//   if (gender === "female") {
//     if (hip > chest && hip > waist) shape = "Pear";
//     else if (chest > hip && chest > waist) shape = "Apple";
//     else if (waist < chest && waist < hip) shape = "Hourglass";
//     else shape = "Rectangle";
//   } else {
//     if (shoulder > waist && chest > waist) shape = "Inverted Triangle";
//     else if (waist < chest && waist < hip) shape = "Trapezoid";
//     else shape = "Rectangle";
//   }

//   return {
//     gender,
//     height: `${height.toFixed(1)} cm`,
//     heightCategory,
//     bodyShape: shape,
//   };
// }

// export default function BodyShapeApp() {
//   const messagesEndRef = useRef(null);

//   const [chatMessages, setChatMessages] = useState([
//     { id: 1, text: "Welcome! Let's calculate your body shape. " + requiredFields[0].question, fromUser: false },
//   ]);
//   const [currentFieldIndex, setCurrentFieldIndex] = useState(0);
//   const [formData, setFormData] = useState({});
//   const [input, setInput] = useState("");
//   const [currentPage, setCurrentPage] = useState("chat");
//   const [chosenStyle, setChosenStyle] = useState("");
//   const [result, setResult] = useState(null);

//   useEffect(() => {
//     messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
//   }, [chatMessages]);

//   const addBotMessage = (text) => {
//     setChatMessages((msgs) => [...msgs, { id: Date.now(), text, fromUser: false }]);
//   };

//   const addUserMessage = (text) => {
//     setChatMessages((msgs) => [...msgs, { id: Date.now(), text, fromUser: true }]);
//   };

//   const handleSend = () => {
//     const userInput = input.trim();
//     if (!userInput) return;
//     addUserMessage(userInput);
//     setInput("");

//     if (currentPage === "chat") {
//       const currentField = requiredFields[currentFieldIndex];

//       if (currentField?.key === "gender") {
//         const val = userInput.toLowerCase();
//         if (val === "male" || val === "female") {
//           setFormData({ ...formData, gender: val });
//           const nextIndex = currentFieldIndex + 1;
//           if (nextIndex < requiredFields.length) {
//             addBotMessage(requiredFields[nextIndex].question);
//             setCurrentFieldIndex(nextIndex);
//           }
//         } else {
//           addBotMessage("Invalid gender. Please type 'male' or 'female'.");
//         }
//       } else if (currentField) {
//         const parsed = parseValueUnit(userInput);
//         if (parsed) {
//           const newFormData = { ...formData, [currentField.key]: parsed };
//           setFormData(newFormData);
//           const nextIndex = currentFieldIndex + 1;
//           if (nextIndex < requiredFields.length) {
//             addBotMessage(requiredFields[nextIndex].question);
//             setCurrentFieldIndex(nextIndex);
//           } else {
//             const resultData = calculateBodyShape(newFormData);
//             setResult(resultData);
//             setCurrentPage("result");
//           }
//         } else {
//           addBotMessage("Invalid format. Please enter a number followed by a unit (cm, inches, feet). Example: 40 cm");
//         }
//       }
//     }
//   };

//   const renderChatPage = () => (
    
       
//       <div style={styles.chatPage}>
//         <div style={styles.chatContainer}>
//           <div style={styles.chatMessages}>
//             {chatMessages.map((msg) => (
//               <div
//                 key={msg.id}
//                 style={{
//                   ...styles.chatMessage,
//                   alignSelf: msg.fromUser ? "flex-end" : "flex-start",
//                   backgroundColor: msg.fromUser ? "#9c5c34" : "#ffcba4",
//                   color: msg.fromUser ? "#fff" : "#5D432C",
//                 }}
//               >
//                 {msg.text}
//               </div>
//             ))}
//             <div ref={messagesEndRef} />
//           </div>
//           <div style={styles.chatInputRow}>
//             <input
//               type="text"
//               placeholder="Type your answer..."
//               value={input}
//               onChange={(e) => setInput(e.target.value)}
//               onKeyPress={(e) => {
//                 if (e.key === "Enter") {
//                   e.preventDefault();
//                   handleSend();
//                 }
//               }}
//               style={styles.chatInput}
//             />
//             <button onClick={handleSend} style={styles.chatSendButton}>
//               Send
//             </button>
//           </div>
//         </div>
//       </div>
    
//   );

//   const renderResultPage = () => {
//     const styleOptions = ["formal", "western", "traditional", "casual", "indowestern"];

//     return (
      
      
//         <div style={styles.resultContainer}>
//           <h2>Your Body Shape Summary</h2>
//           <ul style={styles.resultList}>
//             <li><strong>Gender:</strong> {result.gender}</li>
//             <li><strong>Height:</strong> {result.height}</li>
//             <li><strong>Height Category:</strong> {result.heightCategory}</li>
//             <li><strong>Body Shape:</strong> {result.bodyShape}</li>
//           </ul>

//           <h3>Choose Style for Recommendations</h3>
//           <div style={styles.buttonRow}>
//             {styleOptions.map((style) => (
//               <button
//                 key={style}
//                 onClick={() => {
//                   setChosenStyle(style);
//                   setCurrentPage("recommendations");
//                 }}
//                 style={styles.styleButton}
//               >
//                 {style}
//               </button>
//             ))}
//           </div>

//           <button onClick={restart} style={styles.restartButton}>
//             Restart Calculator
//           </button>
//         </div>
      
//     );
//   };

//   const renderRecommendationPage = () => (
    
    
//       <div style={styles.resultContainer}>
//         <h2>{chosenStyle.charAt(0).toUpperCase() + chosenStyle.slice(1)} Style Recommendations</h2>
//         <p>Here are some great {chosenStyle} outfit ideas for a {result.bodyShape} body type.</p>
//         <ul>
//           <li>Highlight your best features with tailored fits</li>
//           <li>Layering or accessories based on shape symmetry</li>
//           <li>Choose fabrics and cuts that suit your height</li>
//         </ul>

//         <button onClick={() => setCurrentPage("result")} style={styles.styleButton}>
//           Back to Results
//         </button>
//         <button onClick={restart} style={styles.restartButton}>
//           Restart Calculator
//         </button>
//       </div>
  
//   );

//   const restart = () => {
//     setCurrentPage("chat");
//     setChatMessages([
//       { id: 1, text: "Welcome! Let's calculate your body shape. " + requiredFields[0].question, fromUser: false },
//     ]);
//     setCurrentFieldIndex(0);
//     setFormData({});
//     setInput("");
//     setChosenStyle("");
//     setResult(null);
//   };

//   if (currentPage === "chat") return renderChatPage();
//   if (currentPage === "result") return renderResultPage();
//   if (currentPage === "recommendations") return renderRecommendationPage();
//   return null;
// }

// const styles = {
//   chatPage: {
//     background: "linear-gradient(135deg, #ffe7d1 0%, #e6c1a8 100%)",
    
//     minHeight: "100vh",
//     paddingTop: "40px",
//     display: "flex",
//     justifyContent: "center",
//   },
//   chatContainer: {
//     maxWidth: "600px",
//     height: "450px",
//     border: "1px solid #ccc",
//     borderRadius: "12px",
//     display: "flex",
//     flexDirection: "column",
//     backgroundColor: "#fff",
//     boxShadow: "0 0 10px rgba(0,0,0,0.1)",
//   },
//   chatMessages: {
//     flex: 1,
//     padding: "15px",
//     overflowY: "auto",
//     fontSize: "15px",
//   },
//   chatMessage: {
//     padding: "10px 15px",
//     margin: "8px 0",
//     borderRadius: "18px",
//     maxWidth: "75%",
//   },
//   chatInputRow: {
//     display: "flex",
//     borderTop: "1px solid #ddd",
//     padding: "10px",
//   },
//   chatInput: {
//     flex: 1,
//     borderRadius: "20px",
//     border: "1px solid #ccc",
//     padding: "10px 15px",
//     fontSize: "16px",
//   },
//   chatSendButton: {
//     marginLeft: 10,
//     padding: "10px 20px",
//     backgroundColor: "#9c5c34",
//     color: "white",
//     border: "none",
//     borderRadius: "20px",
//     cursor: "pointer",
//   },
//   resultContainer: {
//     padding: 20,
//     maxWidth: 600,
//     margin: "40px auto",
//     backgroundColor: "#fff",
//     borderRadius: 12,
//     boxShadow: "0 0 10px rgba(0,0,0,0.1)",
//   },
//   resultList: {
//     backgroundColor: "#f0f0f0",
//     padding: 15,
//     borderRadius: 8,
//     fontSize: 14,
//     lineHeight: "1.6",
//   },
//   buttonRow: {
//     display: "flex",
//     gap: 10,
//     flexWrap: "wrap",
//     marginTop: 15,
//   },
//   styleButton: {
//     padding: "10px 16px",
//     backgroundColor: "#9c5c34",
//     color: "white",
//     border: "none",
//     borderRadius: 8,
//     cursor: "pointer",
//     textTransform: "capitalize",
//   },
//   restartButton: {
//     marginTop: 30,
//     padding: "10px 20px",
//     backgroundColor: "#d9534f",
//     color: "white",
//     border: "none",
//     borderRadius: 8,
//     cursor: "pointer",
//   },
// };





import React, { useState, useRef, useEffect } from "react";
import axios from "axios";

const requiredFields = [
  { key: "gender", question: "Please enter your gender (male/female):" },
  { key: "shoulder", question: "Enter your shoulder measurement with unit (e.g., 40 cm):" },
  { key: "chest", question: "Enter your chest measurement with unit (e.g., 90 cm):" },
  { key: "waist", question: "Enter your waist measurement with unit (e.g., 70 cm):" },
  { key: "hip", question: "Enter your hip measurement with unit (e.g., 95 cm):" },
  { key: "height", question: "Enter your height with unit (e.g., 170 cm):" },
];

function parseValueUnit(input) {
  const parts = input.trim().split(" ");
  if (parts.length !== 2) return null;
  const value = parseFloat(parts[0]);
  const unit = parts[1].toLowerCase();
  if (isNaN(value)) return null;
  if (!["cm", "inches", "feet"].includes(unit)) return null;
  return { value, unit };
}

export default function BodyShapeApp() {
  const messagesEndRef = useRef(null);

  const [chatMessages, setChatMessages] = useState([
    { id: 1, text: "Welcome! Let's calculate your body shape. " + requiredFields[0].question, fromUser: false },
  ]);
  const [currentFieldIndex, setCurrentFieldIndex] = useState(0);
  const [formData, setFormData] = useState({});
  const [input, setInput] = useState("");
  const [currentPage, setCurrentPage] = useState("chat");
  const [chosenStyle, setChosenStyle] = useState("");
  const [result, setResult] = useState(null);

  // useEffect(() => {
  //   messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  // }, [chatMessages]);

  const addBotMessage = (text) => {
    setChatMessages((msgs) => [...msgs, { id: Date.now(), text, fromUser: false }]);
  };

  const addUserMessage = (text) => {
    setChatMessages((msgs) => [...msgs, { id: Date.now(), text, fromUser: true }]);
  };

  const handleSend = async () => {
    const userInput = input.trim();
    if (!userInput) return;
    addUserMessage(userInput);
    setInput("");

    const currentField = requiredFields[currentFieldIndex];

    if (currentField?.key === "gender") {
      const val = userInput.toLowerCase();
      if (val === "male" || val === "female") {
        setFormData({ ...formData, gender: val });
        nextField(currentFieldIndex + 1);
      } else {
        addBotMessage("Invalid gender. Please type 'male' or 'female'.");
      }
    } else if (currentField) {
      const parsed = parseValueUnit(userInput);
      if (parsed) {
        const newFormData = { ...formData, [currentField.key]: parsed };
        setFormData(newFormData);
        const nextIndex = currentFieldIndex + 1;
        if (nextIndex < requiredFields.length) {
          nextField(nextIndex);
        } else {
          // ✅ Send to backend here
          console.log("Final Form Data:", newFormData); 
          try {
            const token = localStorage.getItem("token");
            const res = await axios.post("http://localhost:5000/body/body-shapes", newFormData, {
              headers: { Authorization: `Bearer ${token}` },
            });
            setResult(res.data);
            setCurrentPage("result");
          } catch (error) {
            console.error("API error:", error);
            addBotMessage("Error calculating body shape. Please try again.");
          }
        }
      } else {
        addBotMessage("Invalid format. Use number and unit (cm, inches, feet). Ex: 40 cm");
      }
    }
  };

  const nextField = (index) => {
    addBotMessage(requiredFields[index].question);
    setCurrentFieldIndex(index);
  };

  const restart = () => {
    setCurrentPage("chat");
    setChatMessages([
      { id: 1, text: "Welcome! Let's calculate your body shape. " + requiredFields[0].question, fromUser: false },
    ]);
    setCurrentFieldIndex(0);
    setFormData({});
    setInput("");
    setChosenStyle("");
    setResult(null);
  };

  const renderChatPage = () => (
    <div style={styles.chatPage}>
      <div style={styles.chatContainer}>
        <div style={styles.chatMessages}>
          {chatMessages.map((msg) => (
            <div
              key={msg.id}
              style={{
                ...styles.chatMessage,
                alignSelf: msg.fromUser ? "flex-end" : "flex-start",
                backgroundColor: msg.fromUser ? "#9c5c34" : "#ffcba4",
                color: msg.fromUser ? "#fff" : "#5D432C",
              }}
            >
              {msg.text}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
        <div style={styles.chatInputRow}>
          <input
            type="text"
            placeholder="Type your answer..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                handleSend();
              }
            }}
            style={styles.chatInput}
          />
          <button onClick={handleSend} style={styles.chatSendButton}>
            Send
          </button>
        </div>
      </div>
    </div>
  );

  const renderResultPage = () => {
  const styleOptions = ["formal", "western", "traditional", "casual", "indowestern"];
  console.log("Backend Response Data:", result); // Debugging line

  return (
    <div style={styles.resultContainer}>
      <h2>Your Body Shape Summary</h2>
      <ul style={styles.resultList}>
       <li><strong>Gender:</strong> {formData.gender || "Not available"}</li>
<li><strong>Height:</strong> {formData.height?.value + " " + formData.height?.unit || "Not available"}</li>
<li><strong>Height Category:</strong> {result.heightCategory || "Not available"}</li>
<li><strong>Body Shape:</strong> {result.bodyShape || "Not available"}</li>

      </ul>

      <h3>Choose Style for Recommendations</h3>
      <div style={styles.buttonRow}>
        {styleOptions.map((style) => (
          <button
            key={style}
            onClick={() => {
              setChosenStyle(style);
              setCurrentPage("recommendations");
            }}
            style={styles.styleButton}
          >
            {style}
          </button>
        ))}
      </div>

      <button onClick={restart} style={styles.restartButton}>
        Restart Calculator
      </button>
    </div>
  );
};

  const renderRecommendationPage = () => (
    <div style={styles.resultContainer}>
      <h2>{chosenStyle.charAt(0).toUpperCase() + chosenStyle.slice(1)} Style Recommendations</h2>

       <p><strong>Recommended Style Tip:</strong> {result.recommendation}</p>
      <ul>
        {result.dressRecommendations?.length > 0 ? (
          result.dressRecommendations.map((dress, index) => (
            <li key={index}>
              <strong>{dress.title}:</strong> {dress.description}
              {dress.imageUrl && <div><img src={dress.imageUrl} alt={dress.title} style={{ width: 150, marginTop: 10 }} /></div>}
            </li>
          ))
        ) : (
          <li>No recommendations available.</li>
        )}
      </ul>
      <button onClick={() => setCurrentPage("result")} style={styles.styleButton}>
        Back to Results
      </button>
      <button onClick={restart} style={styles.restartButton}>
        Restart Calculator
      </button>
    </div>
  );

  if (currentPage === "chat") return renderChatPage();
  if (currentPage === "result") return renderResultPage();
  if (currentPage === "recommendations") return renderRecommendationPage();
  return null;
}

const styles = {
  chatPage: {
    background: "linear-gradient(135deg, #ffe7d1 0%, #e6c1a8 100%)",
    minHeight: "100vh",
    paddingTop: "40px",
    display: "flex",
    justifyContent: "center",
  },
  chatContainer: {
    maxWidth: "600px",
    height: "450px",
    border: "1px solid #ccc",
    borderRadius: "12px",
    display: "flex",
    flexDirection: "column",
    backgroundColor: "#fff",
    boxShadow: "0 0 10px rgba(0,0,0,0.1)",
  },
  chatMessages: {
    flex: 1,
    padding: "15px",
    overflowY: "auto",
    fontSize: "15px",
  },
  chatMessage: {
    padding: "10px 15px",
    margin: "8px 0",
    borderRadius: "18px",
    maxWidth: "75%",
  },
  chatInputRow: {
    display: "flex",
    borderTop: "1px solid #ddd",
    padding: "10px",
  },
  chatInput: {
    flex: 1,
    borderRadius: "20px",
    border: "1px solid #ccc",
    padding: "10px 15px",
    fontSize: "16px",
  },
  chatSendButton: {
    marginLeft: 10,
    padding: "10px 20px",
    backgroundColor: "#9c5c34",
    color: "white",
    border: "none",
    borderRadius: "20px",
    cursor: "pointer",
  },
  resultContainer: {
    padding: 20,
    maxWidth: 600,
    margin: "40px auto",
    backgroundColor: "#fff",
    borderRadius: 12,
    boxShadow: "0 0 10px rgba(0,0,0,0.1)",
  },
  resultList: {
    backgroundColor: "#f0f0f0",
    padding: 15,
    borderRadius: 8,
    fontSize: 14,
    lineHeight: "1.6",
  },
  buttonRow: {
    display: "flex",
    gap: 10,
    flexWrap: "wrap",
    marginTop: 15,
  },
  styleButton: {
    padding: "10px 16px",
    backgroundColor: "#9c5c34",
    color: "white",
    border: "none",
    borderRadius: 8,
    cursor: "pointer",
    textTransform: "capitalize",
  },
  restartButton: {
    marginTop: 30,
    padding: "10px 20px",
    backgroundColor: "#d9534f",
    color: "white",
    border: "none",
    borderRadius: 8,
    cursor: "pointer",
  },
};
