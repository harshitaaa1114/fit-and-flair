// // import React, { useState } from "react";
// // import { signin } from "../../apis";
// // import { Link, useNavigate } from "react-router-dom";


// // function SignIn() {
// //   const [email, setEmail] = useState("");
// //   const [password, setPassword] = useState("");
// //   const [isLoading, setIsLoading] = useState(false);
// //   const navigate = useNavigate();

// //   const handleSubmit = async (e) => {
// //     e.preventDefault();
// //     setIsLoading(true);
// //     try {
// //       const response = await signin({ email, password }
// //       );
// //       alert(response.data.message);
// //       // Navigate to homepage or dashboard after sign-in
// //       navigate("/");
// //     } catch (error) {
// //       console.log(error);
// //       alert(error.response?.data?.message || "Signin failed");
// //     } finally {
// //       setIsLoading(false);
// //     }
// //   };

 
// //   return (
// //     <div>
      
// //       {isLoading ? (
// //         <div className="spinner"></div>
// //       ) : (
// //         <div style={styles.container}>
// //           <div style={styles.formBox}>
// //             <h3 style={styles.heading}>Sign In</h3>
// //             <form onSubmit={handleSubmit}>
// //               <div className="mb-3 text-start">
// //                 <label htmlFor="email" className="form-label" style={styles.label}>Email</label>
// //                 <input
// //                   type="email"
// //                   id="email"
// //                   placeholder="Enter your email"
// //                   className="form-control"
// //                   value={email}
// //                   onChange={(e) => setEmail(e.target.value)}
// //                   required
// //                 />
// //               </div>
// //               <div className="mb-3 text-start">
// //                 <label htmlFor="password" className="form-label" style={styles.label}>Password</label>
// //                 <input
// //                   type="password"
// //                   id="password"
// //                   placeholder="Enter your password"
// //                   className="form-control"
// //                   value={password}
// //                   onChange={(e) => setPassword(e.target.value)}
// //                   required
// //                 />
// //               </div>
// //               <button  type="submit" className="btn" style={styles.btn}>Sign In</button>
              
// //               <p style={{ marginTop: "20px", color: "#5D432C" }}>
// //                 Don't have an account?{" "}
// //                 <Link to="/signup" style={{ fontWeight: "bold", color: "#000" }}>
// //                   Sign Up
// //                 </Link>
// //               </p>
// //             </form>
// //           </div>
// //         </div>
// //       )}
// //     </div>
// //   );
// // }

// // const styles = {
// //   container: {
// //     background: "linear-gradient(135deg, #ffe7d1 0%, #e6c1a8 100%)",
// //     height: "100vh",
// //     display: "flex",
// //     justifyContent: "center",
// //     alignItems: "center",
// //   },
// //   formBox: {
// //     backgroundImage: `linear-gradient(rgba(255, 231, 209, 0.9), rgba(230, 193, 168, 0.7)), url('Logo.png')`,
// //     backgroundSize: "cover",
// //     backgroundPosition: "center",
// //     padding: "40px",
// //     borderRadius: "10px",
// //     height: "450px",
// //     width: "370px",
// //     boxShadow: "0px 0px 10px rgba(0,0,0,0.2)",
// //     textAlign: "center",
// //   },
// //   heading: {
// //     fontWeight: "bold",
// //     color: "#5D432C",
// //     marginBottom: "30px",
// //   },
// //   label: {
// //     fontWeight: "bold",
// //     color: "#5D432C",
// //   },
// //   btn: {
// //     backgroundColor: "#5D432C",
// //     color: "#fff",
// //     width: "100%",
// //     fontWeight: "bold",
// //   },
// // };

// // export default SignIn;
// import React, { useState } from "react";
// import { signin } from "../../apis";
// import { Link, useNavigate } from "react-router-dom";

// function SignIn() {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const [isLoading, setIsLoading] = useState(false);
//   const navigate = useNavigate();

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     setIsLoading(true);
//     try {
//       const response = await signin({ email, password });
//       alert(response.data.message);

//       // 🔐 Admin check by email
//       if (email === "admin@gmail.com") {
//         navigate("/admindashboard"); // Redirect to admin dashboard
//       } else {
//         navigate("/home"); // Redirect to home or user dashboard
//       }
//     } catch (error) {
//       console.log(error);
//       alert(error.response?.data?.message || "Signin failed");
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   return (
//     <div>
//       {isLoading ? (
//         <div className="spinner"></div>
//       ) : (
//         <div style={styles.container}>
//           <div style={styles.formBox}>
//             <h3 style={styles.heading}>Sign In</h3>
//             <form onSubmit={handleSubmit}>
//               <div className="mb-3 text-start">
//                 <label htmlFor="email" className="form-label" style={styles.label}>Email</label>
//                 <input
//                   type="email"
//                   id="email"
//                   placeholder="Enter your email"
//                   className="form-control"
//                   value={email}
//                   onChange={(e) => setEmail(e.target.value)}
//                   required
//                 />
//               </div>
//               <div className="mb-3 text-start">
//                 <label htmlFor="password" className="form-label" style={styles.label}>Password</label>
//                 <input
//                   type="password"
//                   id="password"
//                   placeholder="Enter your password"
//                   className="form-control"
//                   value={password}
//                   onChange={(e) => setPassword(e.target.value)}
//                   required
//                 />
//               </div>
//               <button type="submit" className="btn" style={styles.btn}>Sign In</button>

//               <p style={{ marginTop: "20px", color: "#5D432C" }}>
//                 Don't have an account?{" "}
//                 <Link to="/signup" style={{ fontWeight: "bold", color: "#000" }}>
//                   Sign Up
//                 </Link>
//               </p>
//             </form>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }

// const styles = {
//   container: {
//     background: "linear-gradient(135deg, #ffe7d1 0%, #e6c1a8 100%)",
//     height: "100vh",
//     display: "flex",
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   formBox: {
//     backgroundImage: `linear-gradient(rgba(255, 231, 209, 0.9), rgba(230, 193, 168, 0.7)), url('Logo.png')`,
//     backgroundSize: "cover",
//     backgroundPosition: "center",
//     padding: "40px",
//     borderRadius: "10px",
//     height: "450px",
//     width: "370px",
//     boxShadow: "0px 0px 10px rgba(0,0,0,0.2)",
//     textAlign: "center",
//   },
//   heading: {
//     fontWeight: "bold",
//     color: "#5D432C",
//     marginBottom: "30px",
//   },
//   label: {
//     fontWeight: "bold",
//     color: "#5D432C",
//   },
//   btn: {
//     backgroundColor: "#5D432C",
//     color: "#fff",
//     width: "100%",
//     fontWeight: "bold",
//   },
// };

// export default SignIn;
// import React, { useState } from "react";
// import { Link, useNavigate } from "react-router-dom";
// import axios from "axios";

// function SignIn() {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const [isLoading, setIsLoading] = useState(false);
//   const navigate = useNavigate();

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     setIsLoading(true);
//     try {
//       const response = await axios.post("http://localhost:5000/api/login", { email, password });
//       alert(response.data.message);
//       navigate("/home"); // or wherever you want
//     } catch (error) {
//       console.log(error);
//       alert(error.response?.data?.message || "Login failed");
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   return (
//     <div>
//       {isLoading ? (
//         <div className="spinner"></div>
//       ) : (
//         <div style={styles.container}>
//           <div style={styles.formBox}>
//             <h3 style={styles.heading}>Sign In</h3>
//             <form onSubmit={handleSubmit}>
//               <div className="mb-3 text-start">
//                 <label htmlFor="email" className="form-label" style={styles.label}>Email</label>
//                 <input
//                   type="email"
//                   id="email"
//                   className="form-control"
//                   value={email}
//                   onChange={(e) => setEmail(e.target.value)}
//                   required
//                 />
//               </div>
//               <div className="mb-3 text-start">
//                 <label htmlFor="password" className="form-label" style={styles.label}>Password</label>
//                 <input
//                   type="password"
//                   id="password"
//                   className="form-control"
//                   value={password}
//                   onChange={(e) => setPassword(e.target.value)}
//                   required
//                 />
//               </div>
//               <button type="submit" className="btn" style={styles.btn}>Sign In</button>
//               <p style={{ marginTop: "20px", color: "#5D432C" }}>
//                 Don't have an account? <Link to="/signup" style={{ fontWeight: "bold", color: "#000" }}>Sign Up</Link>
//               </p>
//             </form>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }

// const styles = {
//   container: {
//     background: "linear-gradient(135deg, #ffe7d1 0%, #e6c1a8 100%)",
//     height: "100vh",
//     display: "flex",
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   formBox: {
//     backgroundImage: `linear-gradient(rgba(255, 231, 209, 0.9), rgba(230, 193, 168, 0.7)), url('Logo.png')`,
//     backgroundSize: "cover",
//     backgroundPosition: "center",
//     padding: "40px",
//     borderRadius: "10px",
//     height: "450px",
//     width: "370px",
//     boxShadow: "0px 0px 10px rgba(0,0,0,0.2)",
//     textAlign: "center",
//   },
//   heading: {
//     fontWeight: "bold",
//     color: "#5D432C",
//     marginBottom: "30px",
//   },
//   label: {
//     fontWeight: "bold",
//     color: "#5D432C",
//   },
//   btn: {
//     backgroundColor: "#5D432C",
//     color: "#fff",
//     width: "100%",
//     fontWeight: "bold",
//   },
// };

// export default SignIn;

import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import { auth, provider } from "../../firebase";
import { signInWithPopup } from "firebase/auth";

function SignIn() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const response = await axios.post("http://localhost:5000/user/login", {
        email,
        password,
      });

      alert(response.data.message);
      localStorage.setItem("token", response.data.token);
      navigate("/"); // Redirect to home or dashboard
    } catch (error) {
      console.error(error);
      alert(error.response?.data?.message || "Login failed");
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;

      const response = await axios.post("http://localhost:5000/user/google-signin", {
        name: user.displayName,
        email: user.email,
      });

      alert(response.data.message);
      navigate("/");
    } catch (error) {
      console.error(error);
      alert("Google Sign-In failed");
    }
  };
  return (
    <div
      style={{
        background: "linear-gradient(135deg, #ffe7d1 0%, #e6c1a8 100%)",
        height: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <div
        style={{
          backgroundImage: `linear-gradient(rgba(255, 231, 209, 0.9), rgba(230, 193, 168, 0.7)), url('Logo.png')`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          padding: "40px",
          borderRadius: "10px",
          height: "520px",
          width: "370px",
          boxShadow: "0px 0px 10px rgba(0,0,0,0.2)",
          textAlign: "center",
        }}
      >
        <h3 style={{ fontWeight: "bold", color: "#5D432C", marginBottom: "30px" }}>
          Sign In
        </h3>

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: "20px", textAlign: "left" }}>
            <label htmlFor="email" style={{ fontWeight: "bold", color: "#5D432C" }}>
              Email
            </label>
            <input
              type="email"
              id="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              style={{
                width: "100%",
                padding: "10px",
                borderRadius: "5px",
                border: "1px solid #ccc",
                marginTop: "5px",
              }}
            />
          </div>

          <div style={{ marginBottom: "20px", textAlign: "left" }}>
            <label htmlFor="password" style={{ fontWeight: "bold", color: "#5D432C" }}>
              Password
            </label>
            <input
              type="password"
              id="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={{
                width: "100%",
                padding: "10px",
                borderRadius: "5px",
                border: "1px solid #ccc",
                marginTop: "5px",
              }}
            />
          </div>

          <button
            type="submit"
            style={{
              backgroundColor: "#5D432C",
              color: "#fff",
              width: "100%",
              padding: "10px",
              border: "none",
              borderRadius: "5px",
              fontWeight: "bold",
            }}
          >
            {isLoading ? "Signing in..." : "Sign In"}
          </button>

          <button
            type="button"
            onClick={handleGoogleSignIn}
            className="btn btn-danger mt-3 w-100"
            style={{
              marginTop: "15px",
              width: "100%",
              fontWeight: "bold",
            }}
          >
            Google Sign-In
          </button>

          <p style={{ marginTop: "15px", color: "#5D432C" }}>
            Don’t have an account?{" "}
            <Link to="/signup" style={{ fontWeight: "bold", color: "#000" }}>
              Sign Up
            </Link>
          </p>
          <p 
           style={{ color: "#5D432C", marginTop: "10px" }}>
            <Link to="/forgot" style={{ fontWeight: "bold", color: "#000" }}>
              Forgot Password?
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
}

export default SignIn;
