import React from 'react';
import { useNavigate } from 'react-router-dom';

const RoleSelection = () => {
  const navigate = useNavigate();

  const handleUserClick = () => {
    navigate('/home'); // User Dashboard
  };

  const handleAdminClick = () => {
    navigate('/adminsignin'); // Admin Sign In Page (You’ll create this route)
  };

  return (
    <div style={styles.container}>
      <h2>Select Role</h2>
      <div style={styles.buttonContainer}>
        <button onClick={handleUserClick} style={styles.button}>User</button>
        <button onClick={handleAdminClick} style={styles.button}>Admin</button>
      </div>
    </div>
  );
};

const styles = {
  container: {
    height: '100vh',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff7f2',
    fontFamily: 'Poppins',
  },
  buttonContainer: {
    display: 'flex',
    gap: '2rem',
    marginTop: '2rem',
  },
  button: {
    padding: '1rem 2rem',
    fontSize: '1.2rem',
    borderRadius: '10px',
    border: 'none',
    backgroundColor: '#ff7f50',
    color: 'white',
    cursor: 'pointer',
  },
};

export default RoleSelection;
