// src/components/Indowestern.js
import React from 'react';
import DressCategoryPage from './DressCategoryPage';

const dresses = [
  {
    title: "Kurti with Jeans",
    description: "Fusion of Indian and Western, stylish and comfortable.",
    imageUrl: "/images/indowestern1.jpg"
  },
  {
    title: "Dhoti Pants & Crop Top",
    description: "Trendy Indowestern outfit with cultural flair.",
    imageUrl: "/images/indowestern2.jpg"
  }
];

const Indowestern = () => <DressCategoryPage title="Indowestern Styles" dresses={dresses} />;
export default Indowestern;
