import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  createCategory,
  getAllCategories,
  deleteCategory,
  deleteAllCategories,
} from "../../apis/categoryAPI"; // ✅ Update path if needed

const AdminCategoryPage = () => {
  const [categories, setCategories] = useState([]);
  const [newCategory, setNewCategory] = useState("");

  const styles = {
    page: {
      padding: "40px 20px",
      fontFamily: "Segoe UI, sans-serif",
      background: "linear-gradient(to right, #ffe7d1, #e6c1a8)",
      minHeight: "100vh",
    },
    heading: {
      textAlign: "center",
      fontSize: "32px",
      fontWeight: "bold",
      color: "#9c5c34",
      marginBottom: "30px",
    },
    form: {
      textAlign: "center",
      marginBottom: "30px",
    },
    input: {
      padding: "10px",
      borderRadius: "8px",
      border: "1px solid #ccc",
      marginRight: "10px",
      width: "250px",
    },
    button: {
      padding: "10px 16px",
      backgroundColor: "#9c5c34",
      color: "#fff",
      border: "none",
      borderRadius: "8px",
      cursor: "pointer",
      marginRight: "10px",
    },
    cardGrid: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
      gap: "20px",
      maxWidth: "1000px",
      margin: "0 auto",
    },
    card: {
      background: "#fff",
      padding: "20px",
      borderRadius: "16px",
      boxShadow: "0 8px 20px rgba(0, 0, 0, 0.15)",
      textAlign: "center",
    },
    cardTitle: {
      fontSize: "18px",
      color: "#9c5c34",
      marginBottom: "10px",
    },
    deleteBtn: {
      backgroundColor: "#e74c3c",
      color: "#fff",
      border: "none",
      borderRadius: "6px",
      padding: "8px 12px",
      cursor: "pointer",
      fontSize: "14px",
    },
  };

  // ✅ Fetch all categories
  const fetchCategories = async () => {
    try {
      const res = await getAllCategories();
      setCategories(res.data.categories || []);
    } catch (err) {
      alert("Failed to load categories");
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  // ✅ Add a category
  const handleAdd = async () => {
    if (!newCategory.trim()) return alert("Enter category name");
    try {
      await createCategory({ categoryName: newCategory });
      setNewCategory("");
      fetchCategories();
    } catch (err) {
      alert("Failed to add category");
    }
  };

  // ✅ Delete single category
  const handleDelete = async (id) => {
    try {
      await deleteCategory(id);
      fetchCategories();
    } catch (err) {
      alert("Failed to delete category");
    }
  };

  // ✅ Delete all categories
  const handleDeleteAll = async () => {
    if (window.confirm("Are you sure you want to delete all categories?")) {
      try {
        await deleteAllCategories();
        fetchCategories();
      } catch (err) {
        alert("Failed to delete all categories");
      }
    }
  };

  return (
    <div style={styles.page}>
      <h2 style={styles.heading}>Manage Categories</h2>

      <div style={styles.form}>
        <input
          type="text"
          placeholder="Enter new category"
          value={newCategory}
          onChange={(e) => setNewCategory(e.target.value)}
          style={styles.input}
        />
        <button style={styles.button} onClick={handleAdd}>Add</button>
        <button
          style={{ ...styles.button, backgroundColor: "#a22" }}
          onClick={handleDeleteAll}
        >
          Delete All
        </button>
      </div>

      <div style={styles.cardGrid}>
        {categories.map((cat) => (
          <motion.div
            key={cat._id}
            style={styles.card}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <div style={styles.cardTitle}>{cat.categoryName}</div>
            <button
              style={styles.deleteBtn}
              onClick={() => handleDelete(cat._id)}
            >
              Delete
            </button>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default AdminCategoryPage;
