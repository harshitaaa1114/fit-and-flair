// import React, { useState } from "react";
// import Navbar from "./Navbar";

// function HowToStylePage() {
//   const [gender, setGender] = useState("");
//   const [category, setCategory] = useState("");

//   const styleData = {
//     female: {
//       clothing: [
//         {
//           title: "A-line Dress",
//           description: "Flatters pear-shaped bodies with a slim waist.",
//           image: "/download.jpg",
//         },
//         {
//           title: "Peplum Top",
//           description: "Adds volume to the hips and defines the waistline.",
//           image: "/image.png",
//         },
//       ],
//       accessories: [
//         {
//           title: "Pearl Earrings",
//           description: "Elegant and timeless, enhances facial features.",
//           image: "/female-accessories.jpg",
//         },
//       ],
//       footwear: [
//         {
//           title: "Block Heels",
//           description: "Height and comfort, balances curves.",
//           image: "/female-footwear.jpg",
//         },
//       ],
//     },
//     male: {
//       clothing: [
//         {
//           title: "Slim Fit Blazer",
//           description: "Highlights broad shoulders and a structured fit.",
//           image: "/male-clothing1.jpg",
//         },
//         {
//           title: "Tailored Shirt",
//           description: "Neat and professional, fits well on chest and shoulders.",
//           image: "/male-clothing2.jpg",
//         },
//       ],
//       accessories: [
//         {
//           title: "Leather Watch",
//           description: "Adds class and balances formality.",
//           image: "/male-accessories.jpg",
//         },
//       ],
//       footwear: [
//         {
//           title: "Oxford Shoes",
//           description: "Classic and elegant for formal outfits.",
//           image: "/male-footwear.jpg",
//         },
//       ],
//     },
//   };

//   const selectedData =
//     gender && category ? styleData[gender]?.[category] : null;

//   return (
//     <>
//       <Navbar />
//       <div style={styles.page}>
//         <h1 style={styles.heading}>How to Style</h1>

//         <div style={styles.selectRow}>
//           <select
//             style={styles.selectBox}
//             value={gender}
//             onChange={(e) => setGender(e.target.value)}
//           >
//             <option value="">Select Gender</option>
//             <option value="female">Female</option>
//             <option value="male">Male</option>
//           </select>

//           <select
//             style={styles.selectBox}
//             value={category}
//             onChange={(e) => setCategory(e.target.value)}
//           >
//             <option value="">Select Category</option>
//             <option value="clothing">Clothing</option>
//             <option value="accessories">Accessories</option>
//             <option value="footwear">Footwear</option>
//           </select>
//         </div>

//         {selectedData ? (
//           <div style={styles.cardContainer}>
//             {selectedData.map((item, index) => (
//               <div style={styles.card} key={index}>
//                 <img src={item.image} alt={item.title} style={styles.image} />
//                 <div style={styles.textContent}>
//                   <h2 style={styles.title}>{item.title}</h2>
//                   <p style={styles.description}>{item.description}</p>
//                 </div>
//               </div>
//             ))}
//           </div>
//         ) : (
//           <p style={{ textAlign: "center", color: "#444" }}>
//             Please select gender and category to see recommendations.
//           </p>
//         )}
//       </div>
//     </>
//   );
// }

// const styles = {
//   page: {
//     padding: "40px",
//     backgroundColor: "#f7e0b2",
//     minHeight: "100vh",
//     fontFamily: "sans-serif",
//   },
//   heading: {
//     textAlign: "center",
//     color: "#5D432C",
//     fontSize: "36px",
//     marginBottom: "30px",
//     fontFamily: "'Playfair Display', serif",
//   },
//   selectRow: {
//     display: "flex",
//     justifyContent: "center",
//     gap: "20px",
//     marginBottom: "40px",
//   },
//   selectBox: {
//     padding: "10px 16px",
//     fontSize: "16px",
//     borderRadius: "8px",
//     border: "1px solid #9c5c34",
//     backgroundColor: "#fff",
//     color: "#5D432C",
//     fontWeight: "bold",
//   },
//   cardContainer: {
//   display: "flex",
//   flexWrap: "wrap",            // Allows wrapping on smaller screens
//   justifyContent: "center",    // Centers all cards
//   gap: "30px",                 // Space between cards
//   alignItems: "stretch",       // Align cards properly
// },

  
//   card: {
//     display: "flex",
//     alignItems: "flex-start",
//     backgroundColor: "#fffaf0",
//     boxShadow: "0 10px 20px rgba(0, 0, 0, 0.1)",
//     borderRadius: "16px",
//     maxWidth: "500px",
//     padding: "20px",
//     gap: "24px",
//   },
//   image: {
//     width: "250px",
//     height: "auto",
//     objectFit: "cover",
//     borderRadius: "12px",
//     boxShadow: "0 6px 18px rgba(0, 0, 0, 0.3)",
//   },
//   textContent: {
//     flex: 1,
//     display: "flex",
//     flexDirection: "column",
//     justifyContent: "center",
//     paddingTop: "10px",
//   },
//   title: {
//     fontSize: "24px",
//     fontWeight: "bold",
//     color: "#9c5c34",
//     marginBottom: "12px",
//     fontFamily: "'Playfair Display', serif",
//   },
//   description: {
//     fontSize: "16px",
//     color: "#444",
//     lineHeight: "1.5",
//   },
// };

// export default HowToStylePage;
import React, { useState } from "react";


const banners = {
  female: {
    clothing:
      "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=800&q=80",
    accessories:
      "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=800&q=80",
    footwear:
      "https://images.unsplash.com/photo-1519744792095-2f2205e87b6f?auto=format&fit=crop&w=800&q=80",
  },
  male: {
    clothing:
      "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=800&q=80",
    accessories:
      "https://images.unsplash.com/photo-1509475826633-fed577a2c71b?auto=format&fit=crop&w=800&q=80",
    footwear:
      "https://images.unsplash.com/photo-1519744792095-2f2205e87b6f?auto=format&fit=crop&w=800&q=80",
  },
};

const styleData = {
  female: {
    clothing: [
      {
        title: "A-line Dress",
        description: "Flatters pear-shaped bodies with a slim waist.",
        image:
          "https://images.unsplash.com/photo-1520975928990-d11b0ff7b3bb?auto=format&fit=crop&w=500&q=80",
      },
      {
        title: "Peplum Top",
        description: "Adds volume to the hips and defines the waistline.",
        image:
          "https://images.unsplash.com/photo-1503341455253-b2e723bb3dbb?auto=format&fit=crop&w=500&q=80",
      },
    ],
    accessories: [
      {
        title: "Pearl Earrings",
        description: "Elegant and timeless, enhances facial features.",
        image:
          "https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?auto=format&fit=crop&w=400&q=80",
      },
    ],
    footwear: [
      {
        title: "Block Heels",
        description: "Height and comfort, balances curves.",
        image:
          "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=500&q=80",
      },
    ],
  },
  male: {
    clothing: [
      {
        title: "Slim Fit Blazer",
        description: "Highlights broad shoulders and a structured fit.",
        image:
          "https://images.unsplash.com/photo-1520975928990-d11b0ff7b3bb?auto=format&fit=crop&w=500&q=80&grayscale",
      },
      {
        title: "Tailored Shirt",
        description: "Neat and professional, fits well on chest and shoulders.",
        image:
          "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=500&q=80&grayscale",
      },
    ],
    accessories: [
      {
        title: "Leather Watch",
        description: "Adds class and balances formality.",
        image:
          "https://images.unsplash.com/photo-1509475826633-fed577a2c71b?auto=format&fit=crop&w=400&q=80&grayscale",
      },
    ],
    footwear: [
      {
        title: "Oxford Shoes",
        description: "Classic and elegant for formal outfits.",
        image:
          "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=500&q=80&grayscale",
      },
    ],
  },
};

function HowToStylePage() {
  const [gender, setGender] = useState("");
  const [category, setCategory] = useState("");

  const selectedData =
    gender && category ? styleData[gender]?.[category] : null;

  return (
    <>

      <div style={styles.page}>
        <h1 style={styles.heading}>How to Style</h1>

        {/* Gender + Category Selectors */}
        <div style={styles.selectRow}>
          <select
            style={styles.selectBox}
            value={gender}
            onChange={(e) => setGender(e.target.value)}
            className="animated-select"
          >
            <option value="">Select Gender</option>
            <option value="female">Female 👩</option>
            <option value="male">Male 👨</option>
          </select>

          <select
            style={styles.selectBox}
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="animated-select"
            disabled={!gender}
          >
            <option value="">Select Category</option>
            <option value="clothing">Clothing 👗</option>
            <option value="accessories">Accessories 💍</option>
            <option value="footwear">Footwear 👠</option>
          </select>
        </div>

        {/* Banner Image for selection */}
        {gender && category && (
          <div style={styles.bannerContainer}>
            <img
              src={banners[gender][category]}
              alt={`${gender} ${category} banner`}
              style={styles.bannerImage}
              className="glow"
            />
            <div style={styles.bannerText}>
              <h2>
                {gender.charAt(0).toUpperCase() + gender.slice(1)}'s{" "}
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </h2>
            </div>
          </div>
        )}

        {/* Display selected style cards */}
        {selectedData ? (
          <div style={styles.cardContainer}>
            {selectedData.map((item, index) => (
              <div
                style={styles.card}
                key={index}
                className="tilt-card fade-in-card"
              >
                <img src={item.image} alt={item.title} style={styles.image} />
                <div style={styles.textContent}>
                  <h3 style={styles.title}>{item.title}</h3>
                  <p style={styles.description}>{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ textAlign: "center", color: "#613214", fontStyle: "italic", fontWeight:"600" }}>
            Please select gender and category to see fabulous recommendations!
          </p>
        )}
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Poppins:wght@400;600&display=swap');

        /* Fonts */
        body {
          margin: 0;
          background: linear-gradient(135deg, #ffe7d1 0%, #e6c1a8 100%);
          font-family: 'Poppins', sans-serif;
        }

        h1, h2, h3 {
          font-family: 'Playfair Display', serif;
          color: #613214;
          user-select: none;
        }

        /* Fade-in animation */
        .fade-in-card {
          opacity: 0;
          transform: translateY(30px);
          animation: fadeInUp 0.6s forwards;
        }
        .fade-in-card:nth-child(1) { animation-delay: 0.1s; }
        .fade-in-card:nth-child(2) { animation-delay: 0.25s; }
        .fade-in-card:nth-child(3) { animation-delay: 0.4s; }

        @keyframes fadeInUp {
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        /* Glowing banner image */
        .glow {
          filter: drop-shadow(0 0 10px #d67f2f);
          transition: filter 0.3s ease-in-out;
        }
        .glow:hover {
          filter: drop-shadow(0 0 25px #c07a24);
          cursor: pointer;
          transform: scale(1.05);
          transition: transform 0.3s ease, filter 0.3s ease;
        }

        /* Tilt effect for cards */
        .tilt-card {
          perspective: 1000px;
          transform-style: preserve-3d;
          transition: transform 0.3s ease;
        }
        .tilt-card:hover {
          transform: rotateY(8deg) rotateX(4deg) scale(1.07);
          box-shadow: 0 20px 35px rgba(198, 130, 30, 0.35);
          cursor: pointer;
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        /* Select box styling */
        .animated-select {
          padding: 14px 18px;
          font-size: 16px;
          border-radius: 14px;
          border: 2px solid #d67f2f;
          background-color: #fff8f0;
          color: #613214;
          font-weight: 600;
          min-width: 190px;
          box-shadow: 0 4px 8px rgba(198, 130, 30, 0.15);
          cursor: pointer;
          transition: all 0.3s ease;
          appearance: none;
          background-image:
            url("data:image/svg+xml;utf8,<svg fill='${encodeURIComponent(
              "#613214"
            )}' height='20' viewBox='0 0 24 24' width='20' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/></svg>");
          background-repeat: no-repeat;
          background-position: right 15px center;
          background-size: 20px;
        }
        .animated-select:hover {
          border-color: #a3671f;
        }
        .animated-select:focus {
          border-color: #a3671f;
          outline: none;
          box-shadow: 0 0 12px rgba(166, 103, 31, 0.7);
          background-color: #fff1dc;
        }
        .animated-select:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }
      `}</style>
    </>
  );
}

const styles = {
  page: {
    padding: "40px 30px",
    maxWidth: "1100px",
    margin: "0 auto",
  },
  heading: {
    fontSize: "48px",
    fontWeight: "900",
    marginBottom: "40px",
    textAlign: "center",
  },
  selectRow: {
    display: "flex",
    justifyContent: "center",
    gap: "25px",
    marginBottom: "40px",
    flexWrap: "wrap",
  },
  selectBox: {
    // styles handled via className and inline styles above
  },
  bannerContainer: {
    position: "relative",
    marginBottom: "50px",
    borderRadius: "20px",
    overflow: "hidden",
    boxShadow: "0 15px 40px rgba(198, 130, 30, 0.4)",
    maxWidth: "100%",
  },
  bannerImage: {
    width: "100%",
    height: "280px",
    objectFit: "cover",
    display: "block",
    borderRadius: "20px",
    transition: "transform 0.3s ease",
  },
  bannerText: {
    position: "absolute",
    bottom: "18px",
    left: "24px",
    color: "#f7e4d0",
    textShadow: "2px 2px 10px rgba(102, 55, 0, 0.7)",
    fontSize: "32px",
    fontWeight: "700",
    fontFamily: "'Playfair Display', serif",
    userSelect: "none",
  },
  cardContainer: {
    display: "flex",
    flexWrap: "wrap",
    justifyContent: "center",
    gap: "30px",
  },
  card: {
    backgroundColor: "#fff9f1",
    borderRadius: "18px",
    boxShadow: "0 6px 18px rgba(198, 130, 30, 0.25)",
    width: "280px",
    padding: "15px",
    transition: "box-shadow 0.3s ease",
  },
  image: {
    width: "100%",
    borderRadius: "16px",
    marginBottom: "14px",
  },
  textContent: {
    textAlign: "center",
  },
  title: {
    fontSize: "22px",
    fontWeight: "700",
    marginBottom: "8px",
    color: "#8b4b10",
  },
  description: {
    fontSize: "16px",
    color: "#6e3e0a",
    fontWeight: "500",
  },
};

export default HowToStylePage;
