// // import React from "react";
// // import Navbar from "./Navbar";

// // function About() {
// //   return (
// //     <>
// //       <Navbar />

// //       <div style={styles.container}>
// //         <div style={styles.content}>
// //           <h1 style={styles.heading}>About Fit and Flair</h1>
// //           <p style={styles.paragraph}>
// //             <strong>Fit and Flair</strong> is a style intelligence platform that helps you discover the best outfit choices based on your unique body shape and height. We combine body analysis with fashion recommendations to make styling simple, personalized, and effective.
// //           </p>
// //           <p style={styles.paragraph}>
// //             Whether you're male or female, our tool calculates your body shape using key measurements and then provides curated dress suggestions across categories like casual, formal, traditional, western, and more — all tailored to suit your proportions and preferences.
// //           </p>
// //           <p style={styles.paragraph}>
// //             Our mission is to help you feel confident in your style. No more guessing what looks good — we turn your measurements into meaningful suggestions with visual guides to make dressing up easier and smarter.
// //           </p>
// //           <p style={styles.paragraph}>
// //             <strong>Why Fit and Flair?</strong><br />
// //             • Body shape-based recommendations for both men and women<br />
// //             • Height-aware styling tips for maximum visual balance<br />
// //             • Smart suggestions with images and detailed explanations<br />
// //             • Easy-to-use interface for instant results
// //           </p>
// //           <p style={styles.paragraph}>
// //             Fashion isn’t one-size-fits-all — and we’re here to prove it. Embrace your individuality and let <strong>Fit and Flair</strong> guide your personal style journey.
// //           </p>
// //         </div>
// //         <div style={styles.imageContainer}>
// //           <img
// //             src="/about.png"
// //             alt="female fashion"
// //             style={styles.image}
// //           />
         
// //         </div>
// //       </div>
// //     </>
// //   );
// // }

// // const styles = {
// //   container: {
// //     backgroundColor: "#f7e0b2",
// //     padding: "60px 80px",
// //     minHeight: "100vh",
// //     display: "flex",
// //     justifyContent: "space-between",
// //     alignItems: "center",
// //     boxSizing: "border-box",
// //     flexWrap: "wrap", // optional for responsiveness
// //   },
// //   content: {
// //     flex: 1,
// //     marginRight: "50px",
// //   },
// //   heading: {
// //     fontSize: "48px",
// //     color: "#5D432C",
// //     marginBottom: "30px",
// //     fontFamily: "'Playfair Display', serif",
// //   },
// //   paragraph: {
// //     fontSize: "18px",
// //     color: "#5D432C",
// //     lineHeight: "1.6",
// //     marginBottom: "20px",
// //   },
// //   imageContainer: {
// //     flex: 1,
// //     display: "flex",
// //     gap: "30px",
// //     justifyContent: "center",
// //     flexWrap: "wrap",
// //   },
// //   image: {
// //     height: "700px",
// //     objectFit: "contain",
// //   },
// // };

// // export default About;
// import React, { useEffect, useState } from "react";
// import Navbar from "./Navbar";

// function About() {
//   const [tilt, setTilt] = useState({ rotateX: 0, rotateY: 0 });

//   useEffect(() => {
//     const sections = document.querySelectorAll(".fade-in-section");
//     const observer = new IntersectionObserver(
//       (entries) => {
//         entries.forEach((entry) => {
//           if (entry.isIntersecting) {
//             entry.target.classList.add("visible");
//           }
//         });
//       },
//       { threshold: 0.1 }
//     );
//     sections.forEach((section) => observer.observe(section));
//   }, []);

//   const handleMouseMove = (e) => {
//     const { left, top, width, height } = e.currentTarget.getBoundingClientRect();
//     const x = e.clientX - left - width / 2;
//     const y = e.clientY - top - height / 2;
//     const rotateX = (-y / (height / 2)) * 8;
//     const rotateY = (x / (width / 2)) * 8;
//     setTilt({ rotateX, rotateY });
//   };

//   const handleMouseLeave = () => {
//     setTilt({ rotateX: 0, rotateY: 0 });
//   };

//   const scrollToTop = () => {
//     window.scrollTo({ top: 0, behavior: "smooth" });
//   };

//   return (
//     <>
//       <Navbar />

//       <div style={styles.container}>
//         <div style={styles.content}>

//           <section className="fade-in-section slide-in-left" style={styles.section}>
//             <h1 style={styles.heading}>
//               About <span style={styles.highlight}>Fit and Flair</span>
//             </h1>
//             <p style={styles.paragraph}>
//               <strong>Fit and Flair</strong> is your personal style intelligence platform that transforms your unique body shape and height measurements into smart, curated outfit suggestions. We make fashion easy, personalized, and effective — empowering you to dress with confidence every day.
//             </p>
//           </section>

//           <section className="fade-in-section slide-in-right" style={styles.section}>
//             <h2 style={styles.subheading}>Our Vision</h2>
//             <p style={styles.paragraph}>
//               To revolutionize fashion by embracing individuality, ensuring everyone feels confident and stylish by understanding their unique body shape and proportions.
//             </p>
//           </section>

//           <section className="fade-in-section slide-in-left" style={styles.section}>
//             <h2 style={styles.subheading}>Our Mission</h2>
//             <p style={styles.paragraph}>
//               To provide easy-to-use, data-driven styling tools that recommend outfits based on body shape, height, and personal preferences, making fashion accessible and enjoyable.
//             </p>
//           </section>

//           <section className="fade-in-section slide-in-right" style={styles.section}>
//             <h2 style={styles.subheading}>Why Choose Fit and Flair?</h2>
//             <ul style={styles.benefitsList}>
//               {[
//                 "Personalized Style Recommendations: No generic advice — just tailored suggestions for your body type.",
//                 "Body Shape & Height Awareness: Styling tips that respect your unique proportions.",
//                 "Wide Fashion Categories: Casual, formal, traditional, western, and more, with detailed explanations.",
//                 "Visual Guides: Images and examples to help you visualize the look.",
//                 "Easy & Engaging: A friendly interface that guides you step-by-step.",
//               ].map((text, idx) => (
//                 <li key={idx} className="benefit-item">
//                   <strong>{text.split(":")[0]}:</strong> {text.split(":")[1]}
//                 </li>
//               ))}
//             </ul>
//           </section>

//           <section className="fade-in-section slide-in-left" style={styles.section}>
//             <h2 style={styles.subheading}>Our Commitment</h2>
//             <p style={styles.paragraph}>
//               Fashion is not one-size-fits-all. We are dedicated to celebrating your individuality and making your style journey intuitive, confident, and fun.
//             </p>
//           </section>

          
//         </div>

//         <div
//           style={{
//             ...styles.imageContainer,
//             transform: `perspective(600px) rotateX(${tilt.rotateX}deg) rotateY(${tilt.rotateY}deg)`,
//           }}
//           onMouseMove={handleMouseMove}
//           onMouseLeave={handleMouseLeave}
//           className="fade-in-section slide-in-right"
//         >
//           <img
//             src="/about.png"
//             alt="female fashion"
//             style={styles.image}
//             className="image-zoom"
//           />
//         </div>
//       </div>

//       <style>{`
//         /* Fade in */
//         .fade-in-section {
//           opacity: 0;
//           transform: translateY(20px);
//           transition: opacity 0.8s ease-out, transform 0.8s ease-out;
//         }
//         .fade-in-section.visible {
//           opacity: 1;
//           transform: translateY(0);
//         }
//         /* Slide in alternates */
//         .slide-in-left {
//           transform: translateX(-30px);
//           transition: transform 0.8s ease-out, opacity 0.8s ease-out;
//         }
//         .slide-in-left.visible {
//           transform: translateX(0);
//           opacity: 1;
//         }
//         .slide-in-right {
//           transform: translateX(30px);
//           transition: transform 0.8s ease-out, opacity 0.8s ease-out;
//         }
//         .slide-in-right.visible {
//           transform: translateX(0);
//           opacity: 1;
//         }

//         /* Heading underline animation */
//         h1:hover, h2:hover {
//           cursor: pointer;
//           position: relative;
//         }
//         h1:hover::after, h2:hover::after {
//           content: "";
//           position: absolute;
//           width: 100%;
//           height: 3px;
//           bottom: -6px;
//           left: 0;
//           background: #5D432C;
//           animation: underlineGrow 0.4s forwards;
//         }
//         @keyframes underlineGrow {
//           from {width: 0;}
//           to {width: 100%;}
//         }

//         /* Benefits list hover effect */
//         .benefit-item {
//           margin-bottom: 14px;
//           line-height: 1.5;
//           border-radius: 8px;
//           padding: 8px 12px;
//           transition: background-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
//         }
//         .benefit-item:hover {
//           background-color: #5D432C;
//           color: #ffcba4;
//           transform: scale(1.05);
//           cursor: default;
//         }

//         /* Image zoom and shadow on hover */
//         .image-zoom {
//           transition: transform 0.4s ease, box-shadow 0.4s ease;
//           border-radius: 12px;
//           box-shadow: 0 8px 20px rgba(93, 67, 44, 0.3);
//           will-change: transform;
//         }
//         .image-zoom:hover {
//           transform: scale(1.07);
//           box-shadow: 0 12px 30px rgba(93, 67, 44, 0.5);
//         }

//         /* Scroll to top button */
//         button {
//           font-family: 'Playfair Display', serif;
//         }
//         button:hover {
//           background-color: #9c5c34;
//           color: #ffcba4;
//           transition: background-color 0.3s ease;
//         }
//       `}</style>
//     </>
//   );
// }

// const styles = {
//   container: {
//     background: "linear-gradient(135deg, #ffe7d1 0%, #e6c1a8 100%)",
//     minHeight: "100vh",
//     display: "flex",
//     justifyContent: "space-between",
//     alignItems: "flex-start",
//     boxSizing: "border-box",
//     flexWrap: "wrap",
//     color: "#4B3B23", // softer dark text
//     fontFamily: "'Playfair Display', serif",
//     padding: "60px 80px",
//     borderRadius: "12px",
//   },
//   content: {
//     flex: 1,
//     marginRight: "50px",
//     maxWidth: "600px",
//     position: "relative",
//   },
//   section: {
//     marginBottom: "40px",
//   },
//   heading: {
//     fontSize: "48px",
//     fontWeight: "900",
//     marginBottom: "25px",
//     color: "#5D432C", // darker warm brown for contrast
//     userSelect: "none",
//   },
//   subheading: {
//     fontSize: "32px",
//     marginBottom: "18px",
//     color: "#5D432C", // same warm brown
//     fontWeight: "700",
//     borderBottom: "3px solid #5D432C",
//     paddingBottom: "6px",
//     maxWidth: "fit-content",
//     userSelect: "none",
//   },
//   paragraph: {
//     fontSize: "18px",
//     lineHeight: 1.6,
//     marginBottom: "10px",
//     color: "#4B3B23", // softer text color for body
//   },
//   benefitsList: {
//     paddingLeft: "20px",
//     fontSize: "18px",
//     marginTop: "10px",
//     color: "#4B3B23",
//   },
//   imageContainer: {
//     flex: 1,
//     maxWidth: "450px",
//     display: "flex",
//     justifyContent: "center",
//     alignItems: "center",
//     borderRadius: "12px",
//     willChange: "transform",
//     perspective: "600px",
//     cursor: "grab",
//   },
//   image: {
//     width: "100%",
//     maxHeight: "700px",
//     objectFit: "cover",
//   },
//   highlight: {
//     color: "#7E6138", // softer highlight color
//     fontWeight: "bold",
//   },
// };


// export default About;
import React, { useEffect, useState } from "react";


function About() {
  const [tilt, setTilt] = useState({ rotateX: 0, rotateY: 0 });

  useEffect(() => {
    const sections = document.querySelectorAll(".fade-in-section");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.1 }
    );
    sections.forEach((section) => observer.observe(section));
  }, []);

  const handleMouseMove = (e) => {
    const { left, top, width, height } = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - left - width / 2;
    const y = e.clientY - top - height / 2;
    const rotateX = (-y / (height / 2)) * 8;
    const rotateY = (x / (width / 2)) * 8;
    setTilt({ rotateX, rotateY });
  };

  const handleMouseLeave = () => {
    setTilt({ rotateX: 0, rotateY: 0 });
  };

  return (
    <>
      

      <div style={styles.container}>
        <div style={styles.content}>

          <section className="fade-in-section slide-in-left" style={styles.section}>
            <h1 style={styles.heading}>
              About <span style={styles.highlight}>Fit and Flair</span>
            </h1>
            <p style={styles.paragraph}>
              <strong>Fit and Flair</strong> is your personal style intelligence platform that transforms your unique body shape and height measurements into smart, curated outfit suggestions. We make fashion easy, personalized, and effective — empowering you to dress with confidence every day.
            </p>
          </section>

          <section className="fade-in-section slide-in-right" style={styles.section}>
            <h2 style={styles.subheading}>Our Vision</h2>
            <p style={styles.paragraph}>
              To revolutionize fashion by embracing individuality, ensuring everyone feels confident and stylish by understanding their unique body shape and proportions.
            </p>
          </section>

          <section className="fade-in-section slide-in-left" style={styles.section}>
            <h2 style={styles.subheading}>Our Mission</h2>
            <p style={styles.paragraph}>
              To provide easy-to-use, data-driven styling tools that recommend outfits based on body shape, height, and personal preferences, making fashion accessible and enjoyable.
            </p>
          </section>

          <section className="fade-in-section slide-in-right" style={styles.section}>
            <h2 style={styles.subheading}>Why Choose Fit and Flair?</h2>
            <ul style={styles.benefitsList}>
              {[
                "Personalized Style Recommendations: No generic advice — just tailored suggestions for your body type.",
                "Body Shape & Height Awareness: Styling tips that respect your unique proportions.",
                "Wide Fashion Categories: Casual, formal, traditional, western, and more, with detailed explanations.",
                "Visual Guides: Images and examples to help you visualize the look.",
                "Easy & Engaging: A friendly interface that guides you step-by-step.",
              ].map((text, idx) => (
                <li key={idx} className="benefit-item">
                  <strong>{text.split(":")[0]}:</strong> {text.split(":")[1]}
                </li>
              ))}
            </ul>
          </section>

          <section className="fade-in-section slide-in-left" style={styles.section}>
            <h2 style={styles.subheading}>Our Commitment</h2>
            <p style={styles.paragraph}>
              Fashion is not one-size-fits-all. We are dedicated to celebrating your individuality and making your style journey intuitive, confident, and fun.
            </p>
          </section>
        </div>

        <div
          style={{
            ...styles.imageContainer,
            transform: `perspective(600px) rotateX(${tilt.rotateX}deg) rotateY(${tilt.rotateY}deg)`,
          }}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          className="fade-in-section slide-in-right"
        >
          <img
            src="/about.png"
            alt="female fashion"
            style={styles.image}
            className="image-zoom"
          />
        </div>
      </div>

      <style>{`
        /* Fade in */
        .fade-in-section {
          opacity: 0;
          transform: translateY(20px);
          transition: opacity 0.8s ease-out, transform 0.8s ease-out;
        }
        .fade-in-section.visible {
          opacity: 1;
          transform: translateY(0);
        }
        /* Slide in alternates */
        .slide-in-left {
          transform: translateX(-30px);
          transition: transform 0.8s ease-out, opacity 0.8s ease-out;
        }
        .slide-in-left.visible {
          transform: translateX(0);
          opacity: 1;
        }
        .slide-in-right {
          transform: translateX(30px);
          transition: transform 0.8s ease-out, opacity 0.8s ease-out;
        }
        .slide-in-right.visible {
          transform: translateX(0);
          opacity: 1;
        }

        /* Heading underline animation */
        h1:hover, h2:hover {
          cursor: pointer;
          position: relative;
        }
        h1:hover::after, h2:hover::after {
          content: "";
          position: absolute;
          width: 100%;
          height: 3px;
          bottom: -6px;
          left: 0;
          background: #5D432C;
          animation: underlineGrow 0.4s forwards;
        }
        @keyframes underlineGrow {
          from {width: 0;}
          to {width: 100%;}
        }

        /* Benefits list hover effect */
        .benefit-item {
          margin-bottom: 14px;
          line-height: 1.5;
          border-radius: 8px;
          padding: 8px 12px;
          transition: background-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
        }
        .benefit-item:hover {
          background-color: #5D432C;
          color: #ffcba4;
          transform: scale(1.05);
          cursor: default;
        }

        /* Image zoom and shadow on hover */
        .image-zoom {
          transition: transform 0.4s ease, box-shadow 0.4s ease;
          border-radius: 12px;
          box-shadow: 0 8px 20px rgba(93, 67, 44, 0.3);
          will-change: transform;
        }
        .image-zoom:hover {
          transform: scale(1.07);
          box-shadow: 0 12px 30px rgba(93, 67, 44, 0.5);
        }

        /* Scroll to top button */
        button {
          font-family: 'Playfair Display', serif;
        }
        button:hover {
          background-color: #9c5c34;
          color: #ffcba4;
          transition: background-color 0.3s ease;
        }
      `}</style>
    </>
  );
}

const styles = {
  container: {
    background: "linear-gradient(135deg, #ffe7d1 0%, #e6c1a8 100%)",
    minHeight: "100vh",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    boxSizing: "border-box",
    flexWrap: "wrap",
    color: "#4B3B23", // softer dark text for paragraphs
    fontFamily: "'Playfair Display', serif",
    padding: "60px 80px",
    borderRadius: "12px",
  },
  content: {
    flex: 1,
    marginRight: "50px",
    maxWidth: "600px",
    position: "relative",
  },
  section: {
    marginBottom: "40px",
  },
  heading: {
    fontSize: "48px",
    fontWeight: "900",
    marginBottom: "25px",
    color: "#5D432C", // warm brown for headings
    userSelect: "none",
  },
  subheading: {
    fontSize: "32px",
    marginBottom: "18px",
    color: "#5D432C",
    fontWeight: "700",
    borderBottom: "3px solid #5D432C",
    paddingBottom: "6px",
    maxWidth: "fit-content",
    userSelect: "none",
  },
  paragraph: {
    fontSize: "18px",
    lineHeight: 1.6,
    marginBottom: "10px",
    color: "#4B3B23",
  },
  benefitsList: {
    paddingLeft: "20px",
    fontSize: "18px",
    marginTop: "10px",
    color: "#4B3B23",
  },
  imageContainer: {
    flex: 1,
    maxWidth: "450px",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    borderRadius: "12px",
    willChange: "transform",
    perspective: "600px",
    cursor: "grab",
  },
  image: {
    width: "100%",
    maxHeight: "700px",
    objectFit: "cover",
  },
  highlight: {
    color: "#7E6138",
    fontWeight: "bold",
  },
};

export default About;
