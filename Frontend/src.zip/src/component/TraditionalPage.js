// src/components/Traditional.js
import React from 'react';
import DressCategoryPage from './DressCategoryPage';

const dresses = [
  {
    title: "Saree",
    description: "Elegant and timeless Indian attire.",
    imageUrl: "/images/traditional1.jpg"
  },
  {
    title: "Salwar Kameez",
    description: "Comfortable and classy traditional outfit.",
    imageUrl: "/images/traditional2.jpg"
  }
];

const Traditional = () => <DressCategoryPage title="Traditional Styles" dresses={dresses} />;
export default Traditional;
