// import React, { useEffect, useState } from "react";
// import { Link, useLocation } from "react-router-dom";
// import "bootstrap/dist/css/bootstrap.min.css";

// function Navbar() {
//   const location = useLocation();
//   const [scrolled, setScrolled] = useState(false);

//   useEffect(() => {
//     const handleScroll = () => {
//       setScrolled(window.scrollY > 10);
//     };
//     window.addEventListener("scroll", handleScroll);
//     return () => window.removeEventListener("scroll", handleScroll);
//   }, []);

//   const isActive = (path) => location.pathname === path;

//   const navLinkStyle = {
//     color: "#4a2c2a",
//     fontWeight: "500",
//     fontFamily: "'Playfair Display', serif",
//     textDecoration: "none",
//     transition: "all 0.3s ease",
//     position: "relative",
//     padding: "4px 0",
//   };

//   const activeLinkStyle = {
//     color: "#ff6b6b",
//     fontWeight: "bold",
//   };

//   const navStyle = {
//     backgroundColor: "#f8d4a7",
//     boxShadow: scrolled ? "0 4px 10px rgba(0, 0, 0, 0.2)" : "none",
//     transition: "all 0.3s ease",
//     position: "sticky",
//     top: 0,
//     zIndex: 1000,
//   };

//   const brandStyle = {
//     fontFamily: "'Playfair Display', serif",
//     fontWeight: "700",
//     fontSize: "28px",
//     textDecoration: "none",
//     display: "flex",
//     alignItems: "center",
//     gap: "4px",
//   };

//   const fitStyle = {
//     color: "#7b3f00",
//     fontWeight: "bold",
//   };

//   const andStyle = {
//     fontFamily: "'Dancing Script', cursive",
//     color: "#b14d2f",
//     fontSize: "26px",
//   };

//   const flairStyle = {
//     color: "#944a1f",
//     fontWeight: "bold",
//   };

//   return (
//     <>
//       {/* Google Fonts */}
//       <link
//         href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Dancing+Script&display=swap"
//         rel="stylesheet"
//       />
//       <link
//         rel="stylesheet"
//         href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"
//       />

//       <nav className="navbar navbar-expand-lg" style={navStyle}>
//         <div className="container-fluid px-4">
//           {/* Brand Logo */}
//           <Link className="navbar-brand" to="/" style={brandStyle}>
//             <span style={fitStyle}>FIT</span>
//             <span style={andStyle}>&</span>
//             <span style={flairStyle}>FLAIR</span>
//           </Link>

//           {/* Mobile Toggle Button */}
//           <button
//             className="navbar-toggler"
//             type="button"
//             data-bs-toggle="collapse"
//             data-bs-target="#navbarMenu"
//             aria-controls="navbarMenu"
//             aria-expanded="false"
//             aria-label="Toggle navigation"
//           >
//             <span className="navbar-toggler-icon" />
//           </button>

//           {/* Navbar Links */}
//           <div className="collapse navbar-collapse" id="navbarMenu">
//             <ul className="navbar-nav ms-auto mb-2 mb-lg-0 gap-3 align-items-center">
//               {[
//                 { to: "/home", label: "Home" },
//                 { to: "/about", label: "About" },
//                 { to: "/bodyshapecalculator", label: "Calculator" },
//                 { to: "/howtostyle", label: "How To Style" },
//                 { to: "/contact", label: "Contact" },
//                 { to: "/signup", label: "Sign Up" },
//                 { to: "/signin", label: "Sign In" },
//                 { to: "/logout", label: "Logout" },
//               ].map((link) => (
//                 <li className="nav-item" key={link.to}>
//                   <Link
//                     to={link.to}
//                     className="nav-link"
//                     style={{
//                       ...navLinkStyle,
//                       ...(isActive(link.to) ? activeLinkStyle : {}),
//                     }}
//                     onMouseEnter={(e) => {
//                       e.target.style.color = "#ff6b6b";
//                       e.target.style.transform = "scale(1.05)";
//                     }}
//                     onMouseLeave={(e) => {
//                       e.target.style.color = isActive(link.to)
//                         ? "#ff6b6b"
//                         : "#4a2c2a";
//                       e.target.style.transform = "scale(1)";
//                     }}
//                   >
//                     {link.label}
//                   </Link>
//                 </li>
//               ))}
//             </ul>
//           </div>
//         </div>
//       </nav>
//     </>
//   );
// }

// export default Navbar;
import React, { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { getAuth, onAuthStateChanged, signOut } from "firebase/auth";
import "bootstrap/dist/css/bootstrap.min.css";

function Navbar() {
  const location = useLocation();
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  const auth = getAuth();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
    });
    return () => unsubscribe();
  }, [auth]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const isActive = (path) => location.pathname === path;

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setCurrentUser(null);
      navigate("/signin");
    } catch (error) {
      console.error("Logout Error:", error);
    }
  };

  // Navbar route-based links
  const navLinks = [
    { to: "/home", label: "Home" },
    { to: "/about", label: "About" },
    { to: "/bodyshapecalculator", label: "Calculator" },
    { to: "/howtostyle", label: "How To Style" },
    { to: "/contact", label: "Contact" },
  ];

  return (
    <>
      <link
        href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Dancing+Script&display=swap"
        rel="stylesheet"
      />
      <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"
      />

      <nav
        className="navbar navbar-expand-lg"
        style={{
          backgroundColor: "#f8d4a7",
          boxShadow: scrolled ? "0 4px 10px rgba(0, 0, 0, 0.2)" : "none",
          transition: "all 0.3s ease",
          position: "sticky",
          top: 0,
          zIndex: 1000,
        }}
      >
        <div className="container-fluid px-4">
          <Link
            className="navbar-brand"
            to="/"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontWeight: "700",
              fontSize: "28px",
              textDecoration: "none",
              display: "flex",
              alignItems: "center",
              gap: "4px",
            }}
          >
            <span style={{ color: "#7b3f00", fontWeight: "bold" }}>FIT</span>
            <span
              style={{
                fontFamily: "'Dancing Script', cursive",
                color: "#b14d2f",
                fontSize: "26px",
              }}
            >
              &
            </span>
            <span style={{ color: "#944a1f", fontWeight: "bold" }}>FLAIR</span>
          </Link>

          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarMenu"
            aria-controls="navbarMenu"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon" />
          </button>

          <div className="collapse navbar-collapse" id="navbarMenu">
            <ul className="navbar-nav ms-auto mb-2 mb-lg-0 gap-3 align-items-center">
              {navLinks.map((link) => (
                <li className="nav-item" key={link.label}>
                  <Link
                    to={link.to}
                    className="nav-link"
                    style={{
                      color: isActive(link.to) ? "#ff6b6b" : "#4a2c2a",
                      fontWeight: isActive(link.to) ? "bold" : "500",
                      fontFamily: "'Playfair Display', serif",
                      textDecoration: "none",
                    }}
                    onMouseEnter={(e) => {
                      e.target.style.color = "#ff6b6b";
                      e.target.style.transform = "scale(1.05)";
                    }}
                    onMouseLeave={(e) => {
                      e.target.style.color = isActive(link.to)
                        ? "#ff6b6b"
                        : "#4a2c2a";
                      e.target.style.transform = "scale(1)";
                    }}
                  >
                    {link.label}
                  </Link>
                </li>
              ))}

              {currentUser ? (
                <li className="nav-item">
                  <button
                    onClick={handleLogout}
                    className="btn btn-link nav-link"
                    style={{
                      cursor: "pointer",
                      color: "#4a2c2a",
                      fontWeight: "500",
                      fontFamily: "'Playfair Display', serif",
                      textDecoration: "none",
                    }}
                    onMouseEnter={(e) => {
                      e.target.style.color = "#ff6b6b";
                      e.target.style.transform = "scale(1.05)";
                    }}
                    onMouseLeave={(e) => {
                      e.target.style.color = "#4a2c2a";
                      e.target.style.transform = "scale(1)";
                    }}
                  >
                    Logout
                  </button>
                </li>
              ) : (
                <>
                  <li className="nav-item">
                    <Link
                      to="/signup"
                      className="nav-link"
                      style={{
                        color: isActive("/signup") ? "#ff6b6b" : "#4a2c2a",
                        fontWeight: isActive("/signup") ? "bold" : "500",
                        fontFamily: "'Playfair Display', serif",
                        textDecoration: "none",
                      }}
                      onMouseEnter={(e) => {
                        e.target.style.color = "#ff6b6b";
                        e.target.style.transform = "scale(1.05)";
                      }}
                      onMouseLeave={(e) => {
                        e.target.style.color = isActive("/signup")
                          ? "#ff6b6b"
                          : "#4a2c2a";
                        e.target.style.transform = "scale(1)";
                      }}
                    >
                      Sign Up
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link
                      to="/signin"
                      className="nav-link"
                      style={{
                        color: isActive("/signin") ? "#ff6b6b" : "#4a2c2a",
                        fontWeight: isActive("/signin") ? "bold" : "500",
                        fontFamily: "'Playfair Display', serif",
                        textDecoration: "none",
                      }}
                      onMouseEnter={(e) => {
                        e.target.style.color = "#ff6b6b";
                        e.target.style.transform = "scale(1.05)";
                      }}
                      onMouseLeave={(e) => {
                        e.target.style.color = isActive("/signin")
                          ? "#ff6b6b"
                          : "#4a2c2a";
                        e.target.style.transform = "scale(1)";
                      }}
                    >
                      Sign In
                    </Link>
                  </li>
                </>
              )}
            </ul>
          </div>
        </div>
      </nav>
    </>
  );
}

export default Navbar;
