
// import React from "react";
// import Navbar from "./Navbar";

// function HomePage() {
//   return (
//     <>
//       <Navbar />

//       <div style={styles.container}>
        
//         <img src="/Female.png" alt="female" style={styles.image} />

        
//         <div style={styles.centerContent}>
//           { <h1 style={styles.brand}>
//             <span style={styles.fit}>FIT</span>{" "} <br/>
//             <span style={styles.and}>&</span>{" "}<br/>
//             <span style={styles.flair}>FLAIR</span>
//           </h1> }
          
//           <p style={styles.subtitle}>
//             Discover your body shape and unlock your perfect style
//           </p>
//         </div>

        
//         <img src="/male.png" alt="male" style={styles.image} />
//       </div>
//     </>
//   );
// }

// const styles = {
//   container: {
//     display: "flex",
//     alignItems: "center",
//     justifyContent: "space-between",
//     padding: "60px 80px",
//     backgroundColor: "#f7e0b2",
//     minHeight: "93vh",
//     boxSizing: "border-box",
//   },
//   image: {
//     height: "400px",
//     //objectFit: "contain",
//     width:"240px",
    
//   },
//   centerContent: {
//     textAlign: "center",
//     flex: 1,
//     padding: "0 60px",
//     top:"80px",
//   },
//   brand: {
//     fontSize: "64px",
//     fontWeight: "bold",
//     letterSpacing: "4px",
//     margin: "0 0 20px 0",
//     color: "#5D432C",
//   },
//   fit: {
//     color: "#9c5c34",
//     fontFamily: "'Playfair Display', serif"

//   },
//   and: {
//     color: "#000",
//     //fontStyle: "italic",
//     fontFamily: "'Dancing Script', cursive"

//   },
//   flair: {
//     color: "#c1662c",
//     fontFamily: "'Playfair Display', serif"

//   },
//   subtitle: {
//     fontSize: "20px",
//     color: "#5D432C",
//     fontWeight: "500",
//     margin: 0,
//   },
// };

// export default HomePage;
import React, { useEffect } from "react";

//import BodyShapeApp from "./BodyShapeCalculator.js";
import HowToStylePage from "./HowToStyle.js";
import About from "./About.js";
import { useNavigate } from 'react-router-dom';
import ContactPage from "./Contact.js";


function HomePage() {
  const styles = {
    page: {
      // backgroundColor: "#fff8ef",
       background: "linear-gradient(135deg, #ffe7d1 0%, #e6c1a8 100%)",
      minHeight: "100vh",
      display: "flex",
      flexDirection: "column",
      fontFamily: "'Poppins', sans-serif",
    },
    hero: {
      flex: 1,
      display: "flex",
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "80px",
      flexWrap: "wrap",
      gap: "40px",
    },
    left: {
      flex: 1,
      minWidth: "300px",
      animation: "fadeInLeft 1s ease forwards",
      opacity: 0,
    },
    heading: {
      fontSize: "60px",
      fontWeight: "700",
      color: "#4a2c2a",
      marginBottom: "20px",
      lineHeight: "1.2",
    },
    highlight: {
      color: "#ff6b6b",
    },
    text: {
      fontSize: "20px",
      color: "#5f4339",
      marginBottom: "30px",
    },
    image: {
      width: "100%",
      maxWidth: "600px",
      borderRadius: "20px",
      boxShadow: "0 8px 24px rgba(0, 0, 0, 0.15)",
      transition: "transform 0.3s ease",
      animation: "fadeInRight 1s ease forwards",
      opacity: 0,
    },
    button: {
      padding: "14px 28px",
      backgroundColor: "#ff6b6b",
      border: "none",
      borderRadius: "8px",
      fontSize: "16px",
      fontWeight: "600",
      color: "#fff",
      cursor: "pointer",
      transition: "background 0.3s",
    },
    buttonHover: {
      backgroundColor: "#e95555",
    },
    keyframes: `
      @keyframes fadeInLeft {
        from { opacity: 0; transform: translateX(-40px); }
        to { opacity: 1; transform: translateX(0); }
      }
      @keyframes fadeInRight {
        from { opacity: 0; transform: translateX(40px); }
        to { opacity: 1; transform: translateX(0); }
      }
    `,
  };

  useEffect(() => {
    const style = document.createElement("style");
    style.innerText = styles.keyframes;
    document.head.appendChild(style);
  }, []);
 const navigate = useNavigate();
const gotobodyshapecalculator = () => {
  navigate("/bodyshapecalculator");
};

  return (
    <>
      
      <div style={styles.page}>
        <div style={styles.hero}>
          {/* Left Side Content */}
          <div style={styles.left}>
            <h1 style={styles.heading}>
              Know Your <span style={styles.highlight}>Body Shape</span>
            </h1>
            <p style={styles.text}>
              Discover what fits you best. Explore personalized fashion tips, clothing choices, and more—all tailored to your body type.
            </p>
            <button onClick = {gotobodyshapecalculator}
              style={styles.button}
              onMouseOver={(e) => (e.currentTarget.style.backgroundColor = "#e95555")}
              onMouseOut={(e) => (e.currentTarget.style.backgroundColor = "#ff6b6b")}
            >
              Styling now
            </button>
          </div>

          {/* Right Side Image */}
          <img
            src="/bodyshape.jpg"
            alt="Body Types"
            style={styles.image}
            onMouseOver={(e) => (e.currentTarget.style.transform = "scale(1.03)")}
            onMouseOut={(e) => (e.currentTarget.style.transform = "scale(1)")}
          />
        </div>
      </div>
      <HowToStylePage />
      <About/>
      <ContactPage/>
    </>
  );
}

export default HomePage;
