// src/components/Formal.js
import React from 'react';
import DressCategoryPage from './DressCategoryPage';

const dresses = [
  {
    title: "Blazer Set",
    description: "Perfect for meetings and interviews; looks polished and confident.",
    imageUrl: "/images/formal1.jpg"
  },
  {
    title: "White Shirt & Trousers",
    description: "A classic combination that always works for formal occasions.",
    imageUrl: "/images/formal2.jpg"
  }
];

const Formal = () => <DressCategoryPage title="Formal Styles" dresses={dresses} />;
export default Formal;
