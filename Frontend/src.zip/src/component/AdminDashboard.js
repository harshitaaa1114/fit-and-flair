// import React, { useEffect, useState } from "react";
// import {
//   getAllCategories,
//   createCategory,
//   deleteCategory,
//   deleteAllCategories,
// } from "../apis";

// function AdminDashboard() {
//   const [categories, setCategories] = useState([]);
//   const [categoryName, setCategoryName] = useState("");
//   const [loading, setLoading] = useState(false);

//   // Fetch categories from backend
//   const fetchCategories = async () => {
//     setLoading(true);
//     try {
//       const res = await getAllCategories();
//       setCategories(res.data.categories);
//     } catch (err) {
//       alert("Error fetching categories");
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   useEffect(() => {
//     fetchCategories();
//   }, []);

//   // Add new category
//   const handleAddCategory = async (e) => {
//     e.preventDefault();
//     if (!categoryName.trim()) return alert("Enter category name");
//     try {
//       await createCategory({ categoryName });
//       setCategoryName("");
//       fetchCategories();
//     } catch (err) {
//       alert("Error creating category");
//       console.error(err);
//     }
//   };

//   // Delete a single category by id
//   const handleDeleteCategory = async (id) => {
//     if (!window.confirm("Are you sure you want to delete this category?")) return;
//     try {
//       await deleteCategory(id);
//       fetchCategories();
//     } catch (err) {
//       alert("Error deleting category");
//       console.error(err);
//     }
//   };

//   // Delete all categories
//   const handleDeleteAll = async () => {
//     if (!window.confirm("Are you sure you want to delete ALL categories?")) return;
//     try {
//       await deleteAllCategories();
//       fetchCategories();
//     } catch (err) {
//       alert("Error deleting all categories");
//       console.error(err);
//     }
//   };

//   return (
//     <div style={{ padding: "20px", maxWidth: "600px", margin: "auto" }}>
//       <h2>Admin Dashboard - Categories</h2>

//       <form onSubmit={handleAddCategory} style={{ marginBottom: "20px" }}>
//         <input
//           type="text"
//           value={categoryName}
//           placeholder="New category name"
//           onChange={(e) => setCategoryName(e.target.value)}
//           style={{ padding: "10px", width: "70%", marginRight: "10px" }}
//         />
//         <button type="submit" style={{ padding: "10px 20px" }}>
//           Add Category
//         </button>
//       </form>

//       {loading ? (
//         <p>Loading categories...</p>
//       ) : categories.length === 0 ? (
//         <p>No categories found.</p>
//       ) : (
//         <ul style={{ listStyle: "none", padding: 0 }}>
//           {categories.map((cat) => (
//             <li
//               key={cat._id}
//               style={{
//                 marginBottom: "10px",
//                 display: "flex",
//                 justifyContent: "space-between",
//                 alignItems: "center",
//               }}
//             >
//               <span>{cat.categoryName}</span>
//               <button
//                 onClick={() => handleDeleteCategory(cat._id)}
//                 style={{ color: "red", cursor: "pointer" }}
//                 title="Delete category"
//               >
//                 Delete
//               </button>
//             </li>
//           ))}
//         </ul>
//       )}

//       {categories.length > 0 && (
//         <button
//           onClick={handleDeleteAll}
//           style={{
//             marginTop: "20px",
//             backgroundColor: "red",
//             color: "white",
//             padding: "10px 15px",
//             cursor: "pointer",
//           }}
//           title="Delete all categories"
//         >
//           Delete All Categories
//         </button>
//       )}
//     </div>
//   );
// }

// export default AdminDashboard;



import React from "react";
import { motion } from "framer-motion";

const cardData = [
  {
    title: "Manage Categories",
    description: "Create, update, or delete fashion categories.",
    path: "/admincategories",
  },
  {
    title: "Manage Dresses",
    description: "Add, view, or modify dress recommendations.",
    path: "/admin/dresses",
  },
  {
    title: "How To Style",
    description: "Control goals, styles & recommendations.",
    path: "/admin/style",
  },
];

const AdminDashboard = () => {
  const styles = {
    page: {
      background: "linear-gradient(to right, #ffe7d1, #e6c1a8)",
      minHeight: "100vh",
      padding: "40px 20px",
      fontFamily: "Segoe UI, sans-serif",
    },
    heading: {
      textAlign: "center",
      fontSize: "36px",
      color: "#9c5c34",
      marginBottom: "40px",
      fontWeight: "bold",
    },
    cardGrid: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
      gap: "30px",
      maxWidth: "1000px",
      margin: "0 auto",
    },
    card: {
      backgroundColor: "#fff",
      borderRadius: "20px",
      padding: "25px",
      boxShadow: "0 8px 20px rgba(0, 0, 0, 0.15)",
      textAlign: "center",
      transition: "transform 0.3s ease",
      cursor: "pointer",
    },
    cardTitle: {
      fontSize: "22px",
      marginBottom: "10px",
      color: "#9c5c34",
      fontWeight: "600",
    },
    cardDesc: {
      fontSize: "15px",
      color: "#5d432c",
      marginBottom: "20px",
    },
    button: {
      padding: "10px 18px",
      backgroundColor: "#9c5c34",
      color: "#fff",
      border: "none",
      borderRadius: "8px",
      fontSize: "14px",
      cursor: "pointer",
    },
  };

  const handleNavigate = (path) => {
    window.location.href = path;
  };

  return (
    <div style={styles.page}>
      <motion.h1
        style={styles.heading}
        initial={{ y: -40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6 }}
      >
        Admin Dashboard
      </motion.h1>

      <div style={styles.cardGrid}>
        {cardData.map((card, index) => (
          <motion.div
            key={index}
            style={styles.card}
            whileHover={{ scale: 1.05 }}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.2, duration: 0.5 }}
            onClick={() => handleNavigate(card.path)}
          >
            <div style={styles.cardTitle}>{card.title}</div>
            <div style={styles.cardDesc}>{card.description}</div>
            <button style={styles.button}>Manage</button>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default AdminDashboard;
