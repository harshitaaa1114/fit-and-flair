// src/components/Casual.js
import React from 'react';
import DressCategoryPage from './DressCategoryPage';

const dresses = [
  {
    title: "T-Shirt & Joggers",
    description: "Comfortable outfit for daily wear.",
    imageUrl: "/images/casual1.jpg"
  },
  {
    title: "Loose Shirt & Shorts",
    description: "Breathable and stylish for hot weather.",
    imageUrl: "/images/casual2.jpg"
  }
];

const Casual = () => <DressCategoryPage title="Casual Styles" dresses={dresses} />;
export default Casual;
