// import React, { useState } from "react";
// import Navbar from "./Navbar";

// const ContactPage = () => {
//   const [formData, setFormData] = useState({
//     name: "",
//     email: "",
//     subject: "",
//     message: "",
//   });

//   const [submitted, setSubmitted] = useState(false);

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     console.log("Form submitted:", formData);
//     setSubmitted(true);
//     setFormData({ name: "", email: "", subject: "", message: "" });
//   };

//   return (
//     <>
//       <Navbar />
//       <div style={styles.container}>
//         <div style={styles.card}>
//           <h2 style={styles.heading}>Contact Us</h2>

//           {submitted && <p style={styles.success}>Thank you for your message!</p>}

//           <form onSubmit={handleSubmit}>
//             <div style={styles.formGroup}>
//               <label style={styles.label}>Name</label>
//               <input
//                 type="text"
//                 name="name"
//                 value={formData.name}
//                 onChange={handleChange}
//                 required
//                 style={styles.input}
//               />
//             </div>

//             <div style={styles.formGroup}>
//               <label style={styles.label}>Email</label>
//               <input
//                 type="email"
//                 name="email"
//                 value={formData.email}
//                 onChange={handleChange}
//                 required
//                 style={styles.input}
//               />
//             </div>

//             <div style={styles.formGroup}>
//               <label style={styles.label}>Subject</label>
//               <input
//                 type="text"
//                 name="subject"
//                 value={formData.subject}
//                 onChange={handleChange}
//                 required
//                 style={styles.input}
//               />
//             </div>

//             <div style={styles.formGroup}>
//               <label style={styles.label}>Message</label>
//               <textarea
//                 name="message"
//                 value={formData.message}
//                 onChange={handleChange}
//                 required
//                 rows="5"
//                 style={styles.textarea}
//               ></textarea>
//             </div>

//             <button type="submit" style={styles.button}>Send Message</button>
//           </form>
//         </div>
//       </div>
//     </>
//   );
// };

// const styles = {
//   container: {
//     backgroundColor: "#f8e1af",
//     minHeight: "100vh",
//     padding: "60px 20px",
//     display: "flex",
//     justifyContent: "center",
//     alignItems: "center",
//     fontFamily: "'Segoe UI', sans-serif",
//   },
//   card: {
//     backgroundColor: "#fffdf8",
//     padding: "40px",
//     borderRadius: "16px",
//     boxShadow: "0 8px 24px rgba(0, 0, 0, 0.15)",
//     width: "100%",
//     maxWidth: "450px",
//   },
//   heading: {
//     fontSize: "36px",
//     color: "#5D432C",
//     marginBottom: "30px",
//     fontFamily: "'Playfair Display', serif",
//     textAlign: "center",
//   },
//   formGroup: {
//     marginBottom: "20px",
//   },
//   label: {
//     display: "block",
//     marginBottom: "8px",
//     fontSize: "16px",
//     color: "#5D432C",
//     fontWeight: "500",
//   },
//   input: {
//     width: "100%",
//     padding: "12px",
//     fontSize: "16px",
//     border: "1px solid #ccc",
//     borderRadius: "8px",
//     boxSizing: "border-box",
//   },
//   textarea: {
//     width: "100%",
//     padding: "12px",
//     fontSize: "16px",
//     border: "1px solid #ccc",
//     borderRadius: "8px",
//     resize: "vertical",
//     boxSizing: "border-box",
//   },
//   button: {
//     width: "100%",
//     padding: "14px",
//     backgroundColor: "#5D432C",
//     color: "#fff",
//     fontSize: "16px",
//     border: "none",
//     borderRadius: "8px",
//     cursor: "pointer",
//     transition: "background-color 0.3s ease",
//   },
//   success: {
//     color: "green",
//     marginBottom: "20px",
//     textAlign: "center",
//     fontWeight: "bold",
//   },
// };

// export default ContactPage;
import React, { useState } from "react";

import { FaFacebook, FaInstagram, FaLinkedin, FaTwitter } from "react-icons/fa";

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    setSubmitted(true);
    setFormData({ name: "", email: "", subject: "", message: "" });
    setTimeout(() => setSubmitted(false), 4000);
  };

  return (
    <>
      
      <div style={styles.page}>
        <div style={styles.container} className="fade-in">
          <h2 style={styles.heading}>Get in Touch</h2>

          {submitted && <p style={styles.success}>Thank you for your message!</p>}

          <form onSubmit={handleSubmit}>
            {["name", "email", "subject"].map((field) => (
              <div style={styles.formGroup} key={field}>
                <label style={styles.label}>{field.charAt(0).toUpperCase() + field.slice(1)}</label>
                <input
                  type={field === "email" ? "email" : "text"}
                  name={field}
                  value={formData[field]}
                  onChange={handleChange}
                  required
                  style={styles.input}
                />
              </div>
            ))}

            <div style={styles.formGroup}>
              <label style={styles.label}>Message</label>
              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                required
                rows="5"
                style={styles.textarea}
              ></textarea>
            </div>

            <button type="submit" style={styles.button}>Send Message</button>
          </form>

          <div style={styles.socials}>
            <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" style={styles.icon}><FaFacebook /></a>
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" style={styles.icon}><FaInstagram /></a>
            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" style={styles.icon}><FaLinkedin /></a>
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" style={styles.icon}><FaTwitter /></a>
          </div>
        </div>
      </div>
    </>
  );
};

const styles = {
  page: {
    minHeight: "100vh",
    background: "linear-gradient(135deg, #ffe7d1 0%, #e6c1a8 100%)",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: "60px 20px",
    fontFamily: "'Segoe UI', sans-serif",
  },
  container: {
    backgroundColor: "#fffdf8",
    padding: "40px",
    borderRadius: "20px",
    boxShadow: "0 12px 30px rgba(0, 0, 0, 0.2)",
    maxWidth: "430px",
    width: "100%",
    animation: "fadeIn 1.2s ease-in-out",
  },
  heading: {
    fontSize: "34px",
    color: "#5D432C",
    marginBottom: "25px",
    fontFamily: "'Playfair Display', serif",
    textAlign: "center",
  },
  formGroup: {
    marginBottom: "20px",
  },
  label: {
    display: "block",
    marginBottom: "8px",
    fontSize: "15px",
    fontWeight: "500",
    color: "#5D432C",
  },
  input: {
    width: "100%",
    padding: "12px",
    fontSize: "15px",
    border: "1px solid #ccc",
    borderRadius: "10px",
    transition: "0.3s",
    outline: "none",
  },
  textarea: {
    width: "100%",
    padding: "12px",
    fontSize: "15px",
    border: "1px solid #ccc",
    borderRadius: "10px",
    resize: "vertical",
    transition: "0.3s",
    outline: "none",
  },
  button: {
    width: "100%",
    padding: "14px",
    backgroundColor: "#9c5c34",
    color: "#fff",
    fontSize: "16px",
    border: "none",
    borderRadius: "10px",
    fontWeight: "bold",
    cursor: "pointer",
    transition: "0.3s ease",
  },
  success: {
    color: "green",
    marginBottom: "20px",
    textAlign: "center",
    fontWeight: "bold",
  },
  socials: {
    marginTop: "30px",
    textAlign: "center",
    display: "flex",
    justifyContent: "center",
    gap: "20px",
  },
  icon: {
    color: "#5D432C",
    fontSize: "24px",
    transition: "transform 0.3s ease, color 0.3s ease",
    textDecoration: "none",
  },
};


export default ContactPage;
